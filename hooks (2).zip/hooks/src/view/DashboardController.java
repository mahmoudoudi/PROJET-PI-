/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import Dialog.AlertDialog;
import Service.ServiceCategory;
import Service.ServiceClient;
import Service.ServiceDeliveryMan;
import Service.ServiceFidelityCard;
import Service.ServiceInfo;
import Service.ServiceOrderp;
import Service.ServiceProduct;
import Service.ServiceRateCity;
import Service.Serviceevenement;
import Utils.Database;
import Utils.Validation;
import entities.Client;
import entities.DeliveryMan;
import entities.Evenement;
import entities.Information;
import entities.ratecity;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalTime;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.TablePosition;
import javafx.scene.control.TableView;
import javafx.scene.control.TableView.TableViewSelectionModel;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import static javafx.scene.input.KeyCode.S;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.stage.FileChooser;
import Validation.TextFieldValidation;
import entities.Category;
import entities.Contact;
import entities.FidelityCard;
import entities.Orderp;
import entities.Product;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Hyperlink;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;




/**
 * FXML Controller class
 *
 * @author asus
 */
public class DashboardController implements Initializable {

    @FXML
    private Pane pane;
    @FXML
    private Label module;
    @FXML
    private Button cust;
    @FXML
    private Button prod;
    @FXML
    private Button deliv;
    @FXML
    private Button news;
    @FXML
    private Button events;
    @FXML
    private Button orders;
    @FXML
    private Button logout;
    @FXML
    private GridPane gridhome;
    @FXML
    private GridPane gridcustomers;
    @FXML
    private TableView<Client> table;
    @FXML
    private TableColumn<Client, String> id;
    @FXML
    private TableColumn<Client, String> email;
    @FXML
    private TableColumn<Client, String> name;
    @FXML
    private TableColumn<Client, String> lastname;
    @FXML
    private TableColumn<Client, String> adress;
    @FXML
    private Button delete;

    @FXML
    private TextField filter;
    @FXML
    private Label idcl;
    @FXML
    private Label nameclient;
    @FXML
    private GridPane gridproducts;
    @FXML
    private GridPane griddelivery;
    @FXML
    private GridPane gridevents;
    @FXML
    private GridPane gridnews;
    @FXML
    private GridPane gridratecity;
    @FXML
    private GridPane gridorders;
    @FXML
    private GridPane gridcontact;
    Connection con;
    ObservableList<Client> oblist;
    @FXML
    private TextField nameD;
    @FXML
    private TextField lastnameD;
    @FXML
    private TextField addressD;
    @FXML
    private TextField emailD;
    @FXML
    private TextField phoneD;
    @FXML
    private Button delete1;
    @FXML
    private Button add;
    @FXML
    private Button update;
    @FXML
    private Button ratecity;
    @FXML
    private TableView<DeliveryMan> tableDD;
    @FXML
    private TableColumn<DeliveryMan, Integer> idtb;
    @FXML
    private TableColumn<DeliveryMan, String> nametb;
    @FXML
    private TableColumn<DeliveryMan, String> lastnametb;
    @FXML
    private TableColumn<DeliveryMan, String> addresstb;
    @FXML
    private TableColumn<DeliveryMan, String> emailtb;
    @FXML
    private TableColumn<DeliveryMan, Integer> phonetb;
    @FXML
    private TableColumn<DeliveryMan, String> availabletb;
    @FXML
    private TableColumn<DeliveryMan, Float> scoretb;
    @FXML
    private TableColumn<DeliveryMan, Float> nbscoretb;
    @FXML
    private Label namelabel;
    @FXML
    private Label emaillabel;
    @FXML
    private Label phonelabel;
    @FXML
    private Label addresslabel;
    @FXML
    private Label lastnamelabel;
    @FXML
    private Button reset;
    @FXML
    private TextField search;
    /**
     * Initializes the controller class.
     */
    public ObservableList<DeliveryMan> data = FXCollections.observableArrayList();
    public ObservableList<ratecity> dataR = FXCollections.observableArrayList();
    public ObservableList<Evenement> dataE = FXCollections.observableArrayList();
    public ObservableList<Information> data1;
    @FXML
    private Button fill;
    @FXML
    private TableView<ratecity> tablerate;
    @FXML
    private TableColumn<ratecity, String> city;
    @FXML
    private TableColumn<ratecity, Float> rate;
    @FXML
    private TextField newrate;
    @FXML
    private Button update1;
    @FXML
    private Button pdf;
    @FXML
    private TextField search1;
    @FXML
    private TextField txtname1;
    @FXML
    private TextField txtaddress1;
    @FXML
    private ComboBox<String> combotype1;
    @FXML
    private TextField txtprice1;
    @FXML
    private TextField txtnumber1;
    @FXML
    private TextField txtdescription1;
    @FXML
    private TextField txtimage1;
    @FXML
    private DatePicker combodateD1;
    @FXML
    private DatePicker combodateF1;
    @FXML
    private TableView<Evenement> Eventtv1;
    @FXML
    private TableColumn<Evenement, String> Name1;
    @FXML
    private TableColumn<Evenement, String> Address1;
    public ObservableList<String> type = FXCollections.observableArrayList("peche", "chasse");
    @FXML
    private TableColumn<Evenement, String> Type1;
    @FXML
    private TableColumn<Evenement, Float> Price1;
    @FXML
    private TableColumn<Evenement, Integer> NumberE1;
    @FXML
    private TableColumn<Evenement, String> Description1;
    @FXML
    private TableColumn<Evenement, String> Image1;
    @FXML
    private TableColumn<Evenement, Timestamp> DateD1;
    @FXML
    private TableColumn<Evenement, Timestamp> DateF1;
    @FXML
    private TextField searchTF1;
    @FXML
    private TextArea Texttfx;
    @FXML
    private TextField Subjecttfx;
    @FXML
    private Button Validateenewsfx;
    @FXML
    private TextField Photoofx;
    @FXML
    private Label erreur_subject;
    @FXML
    private Label erreur_date;
    @FXML
    private Label erreur_photo;
    @FXML
    private Label erreur_text;
    @FXML
    private Button UpdateNewsfx;
    @FXML
    private Button DeleteNewsfx;
    @FXML
    private TextField SearchNewsfx;
    @FXML
    private DatePicker Datepickerfx;
    @FXML
    private TableView<Information> tablenews;
    @FXML
    private TableColumn<Information, String> ColumnSubject;
    @FXML
    private TableColumn<Information, String> ColumnText;
    @FXML
    private TableColumn<Information, Timestamp> ColumnDate;
    @FXML
    private TableColumn<Information, String> ColumnPhoto;
    @FXML
    private TextArea EmailContactfx;
    @FXML
    private TextField ClientIdContactfx;
    @FXML
    private Button SendEmailfx;
    @FXML
    private TableView<Contact> TableContact;
    @FXML
    private TableColumn<Contact, Integer> ClientIdColumn;
    @FXML
    private TableColumn<Contact, String> ContactColumn;

    @FXML
    private Hyperlink reclaim1;
    private ObservableList<Contact> Contact1;
    private ObservableList<FidelityCard> fidelitytable;

    //private Connection con=null;
    private PreparedStatement ste = null;
    private ResultSet rs = null;
    @FXML
    private Label searchfidelity;
    @FXML
    private TableColumn<FidelityCard, Integer> Idproduct;
    @FXML
    private TableColumn<FidelityCard, Integer> Points;
    @FXML
    private TableColumn<FidelityCard, Integer> Idclient;
    @FXML
    private TableView<FidelityCard> tablefidelity;
   
    @FXML
    private TableView<Orderp> tableorders;
    @FXML
    private TableColumn<Orderp, Integer> idcliento;
    @FXML
    private TableColumn<Orderp, String> emailcliento;
    @FXML
    private TableColumn<Orderp, Integer> phonenumbero;
    @FXML
    private TableColumn<Orderp, String> paymento;
    @FXML
    private TableColumn<Orderp, Float> totaleo;
 private ObservableList<Orderp> order;
    @FXML
    private TextField namecategorytf;
    @FXML
    private TextField descriptioncategorytf;
    @FXML
    private TableView<Category> tabc;
    @FXML
    private TableColumn<Category, Integer> idc;
    @FXML
    private TableColumn<Category, String> namec;
    @FXML
    private TableColumn<Category, String> desc;
    @FXML
    private TableColumn<Category, Integer> totalCategory;
    public ObservableList<Category> datacategory = FXCollections.observableArrayList();
    public ObservableList<Category> datacategory2 = FXCollections.observableArrayList();
    @FXML
    private Button update2;
    @FXML
    private Button delete2;
    @FXML
    private Button add1;
    @FXML
    private Button reset1;
    @FXML
    private Button promotionc;
    @FXML
    private TextField promo;
    @FXML
    private Button quantitycategory;
    @FXML
    private Label labelnamecategory;
    @FXML
    private Label labeldescategory;
    @FXML
    private Button returntablecategory;
    @FXML
    private Button excelcategoryquantity;
    ServiceCategory serC = new ServiceCategory();
    Category c= new Category();
    @FXML
    private GridPane gridproduct;
    @FXML
    private Button products1;
    @FXML
    private TextField nameproducttf;
    @FXML
    private TextField pricetf;
    @FXML
    private TextField desctf;
    @FXML
    private TextField quantitytf;
    @FXML
    private TableView<Product> tablep;
    @FXML
    private TableColumn<Product, Integer> idt;
    @FXML
    private TableColumn<Product, String> namect;
    @FXML
    private TableColumn<Product, String> namept;
    @FXML
    private TableColumn<Product, String> desct;
    @FXML
    private TableColumn<Product, Integer> quantityt;
    @FXML
    private TableColumn<Product, Float> pricet;
    @FXML
    private TableColumn<Product, Float> promotiont;
    @FXML
    private Button addproduct;
    @FXML
    private Button deleteproduct;
    @FXML
    private Button updateproduct;
    @FXML
    private Button Resetproduct;
    @FXML
    private Button ShowPromotionproduct;
    @FXML
    private Label namecategorylabe;
    @FXML
    private Label nameproductlabel;
    @FXML
    private Label quantitelabel;
    @FXML
    private Label pricelabel;
    @FXML
    private Label promotionlabel;
    @FXML
    private Button Statsproduct;
    @FXML
    private ComboBox listecat;
    @FXML
    private Button BUploadPic;
    @FXML
    private TextField pictf;
    @FXML
    private Button pdfproduct;
    ServiceProduct serP = new ServiceProduct();
    Product p = new Product();
    public ObservableList<Product> dataproduct = FXCollections.observableArrayList();
    @FXML
    private TextField promotiontf;
    
 public DashboardController() {

    }
public boolean controlesaisieCAT()
        {
           boolean saisie=true;
            if(namecategorytf.getText().equals(""))
            {
              labelnamecategory.setText("Please Fill The category name");
              saisie=false;
            }
            else
            {
                labelnamecategory.setText("");
            }
            if(descriptioncategorytf.getText().equals(""))
            {
              labeldescategory.setText("Please Fill The category description");
              saisie=false;
            }
            else 
            {
                labeldescategory.setText("");
            }
            return saisie;
        }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODaff();
        gridhome.toFront();
        con = Database.getInstance().getConnection();
        oblist = FXCollections.observableArrayList();
        fidelitytable = FXCollections.observableArrayList();
     order = FXCollections.observableArrayList();
        /*mohaned*/
        data1 = FXCollections.observableArrayList();
        setCellValueFromTableToTextFiled();
        LoadDataFromDB();
        setCellTbale();
        searchNews();
        Contact1 = FXCollections.observableArrayList();

        setCellTbalecontact();
        LoadDataFromDBcontact();
        /*jass*/ loaddata();
        aff();
        filter();
        try {
            afficherfidelity();
        } catch (SQLException ex) {
            Logger.getLogger(DashboardController.class.getName()).log(Level.SEVERE, null, ex);
        }
      
        try {
            /*loux*/
            /* aff();
            filter();*/
            /*hama*/
            afficherorder();  /*
            } catch (SQLException ex) {
            Logger.getLogger(DashboardController.class.getName()).log(Level.SEVERE, null, ex);
            }*/
        } catch (SQLException ex) {
            Logger.getLogger(DashboardController.class.getName()).log(Level.SEVERE, null, ex);
        }
        /*hama*/
        /*loux*/
        try {
            afficherdelivery();
        } catch (SQLException ex) {
            Logger.getLogger(DashboardController.class.getName()).log(Level.SEVERE, null, ex);
        }
        tableDD.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {

            @Override
            public void changed(ObservableValue observableValue, Object oldValue, Object newValue) {
                if (tableDD.getSelectionModel().getSelectedItem() != null) {
                    TableViewSelectionModel selectionModel = tableDD.getSelectionModel();
                    ObservableList selectedCells = selectionModel.getSelectedCells();
                    TablePosition tablePosition = (TablePosition) selectedCells.get(0);
                    Object val = tablePosition.getTableColumn().getCellData(newValue);
                    int column = tablePosition.getColumn();
                    int row = tablePosition.getRow();
                    float x = tableDD.getItems().get(row).toStringID();

                    String name = tableDD.getItems().get(row).toStringName();
                    String lastname = tableDD.getItems().get(row).toStringLastName();
                    String adressd = tableDD.getItems().get(row).toStringAddress();
                    String emaild = tableDD.getItems().get(row).toStringEmail();
                    int phonedd = tableDD.getItems().get(row).toStringPhoneNumber();

                    nameD.setText(name);
                    lastnameD.setText(lastname);
                    addressD.setText(adressd);
                    emailD.setText(emaild);
                    phoneD.setText(String.valueOf(phonedd));

                }
            }
        });
        FilteredList<DeliveryMan> filteredData = new FilteredList<>(data, b -> true);

        search.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredData.setPredicate(deliveryman -> {

                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }

                String lowerCaseFilter = newValue.toLowerCase();

                if (deliveryman.getFirstname().toLowerCase().indexOf(lowerCaseFilter) != -1) {
                    return true;
                } else if (deliveryman.getLastname().toLowerCase().indexOf(lowerCaseFilter) != -1) {
                    return true;

                } else if (deliveryman.getEmail().toLowerCase().indexOf(lowerCaseFilter) != -1) {
                    return true;

                } else if (String.valueOf(deliveryman.getPhonenumber()).toLowerCase().indexOf(lowerCaseFilter) != -1) {
                    return true;

                } else if (deliveryman.getAvailable().toLowerCase().indexOf(lowerCaseFilter) != -1) {
                    return true;

                } else {
                    return false; // Does not match.
                }
            });
        });

        SortedList<DeliveryMan> sortedData = new SortedList<>(filteredData);

        sortedData.comparatorProperty().bind(tableDD.comparatorProperty());

        tableDD.setItems(sortedData);

        ServiceRateCity serR = new ServiceRateCity();
        try {
            dataR.addAll(serR.readAll());
        } catch (SQLException ex) {
            Logger.getLogger(DashboardController.class.getName()).log(Level.SEVERE, null, ex);
        }
        city.setCellValueFactory(new PropertyValueFactory<ratecity, String>("City"));
        rate.setCellValueFactory(new PropertyValueFactory<ratecity, Float>("Rate"));
        tablerate.setItems(dataR);

        tablerate.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {

            @Override
            public void changed(ObservableValue observableValue, Object oldValue, Object newValue) {
                if (tablerate.getSelectionModel().getSelectedItem() != null) {
                    TableViewSelectionModel selectionModel = tablerate.getSelectionModel();
                    ObservableList selectedCells = selectionModel.getSelectedCells();
                    TablePosition tablePosition = (TablePosition) selectedCells.get(0);
                    Object val = tablePosition.getTableColumn().getCellData(newValue);
                    int column = tablePosition.getColumn();
                    int row = tablePosition.getRow();
                    float x = tablerate.getItems().get(row).toString1();
                    newrate.setText(String.valueOf(x));

                }
            }
        });

        Serviceevenement serE = new Serviceevenement();
        try {
            dataE.addAll(serE.readAll1());
        } catch (SQLException ex) {
            Logger.getLogger(DashboardController.class.getName()).log(Level.SEVERE, null, ex);
        }
        combotype1.setItems(FXCollections.observableArrayList(type));

        Name1.setCellValueFactory(new PropertyValueFactory<Evenement, String>("NameEvent"));
        Address1.setCellValueFactory(new PropertyValueFactory<Evenement, String>("AddressEvent"));
        Type1.setCellValueFactory(new PropertyValueFactory<Evenement, String>("Type"));
        Price1.setCellValueFactory(new PropertyValueFactory<Evenement, Float>("PriceEvent"));
        NumberE1.setCellValueFactory(new PropertyValueFactory<Evenement, Integer>("NbrPlace"));
        Description1.setCellValueFactory(new PropertyValueFactory<Evenement, String>("DescriptionEvent"));
        Image1.setCellValueFactory(new PropertyValueFactory<Evenement, String>("Image"));
        DateD1.setCellValueFactory(new PropertyValueFactory<Evenement, Timestamp>("dateD"));
        DateF1.setCellValueFactory(new PropertyValueFactory<Evenement, Timestamp>("dateF"));

        Eventtv1.setItems(dataE);
        //HATEM CATEGORY
        delete2.setDisable(true);
        update2.setDisable(true);
        promotionc.setDisable(true);
                
        try {
            datacategory.addAll(serC.readAll(c));
        } catch (SQLException ex) {
            Logger.getLogger(DashboardController.class.getName()).log(Level.SEVERE, null, ex);
        }
        idc.setCellValueFactory(new PropertyValueFactory<Category,Integer>("IdCategory"));
           namec.setCellValueFactory(new PropertyValueFactory<Category,String>("NameCategory"));
            desc.setCellValueFactory(new PropertyValueFactory<Category,String>("DescriptionCategory"));
            //totalCategory.setCellValueFactory(new PropertyValueFactory<Category,Integer>("total"));
          idc.prefWidthProperty().bind(tabc.widthProperty().divide(100)); 
          tabc.setItems(datacategory);
       tabc.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
@Override
public void changed(ObservableValue observableValue, Object oldValue, Object newValue) {
    
if(tabc.getSelectionModel().getSelectedItem() != null) 
{   
            delete2.setDisable(false);
        update2.setDisable(false);
        promotionc.setDisable(false);
TableViewSelectionModel selectionModel = tabc.getSelectionModel();
ObservableList selectedCells = selectionModel.getSelectedCells();
TablePosition tablePosition = (TablePosition) selectedCells.get(0);
int row = tablePosition.getRow();
namecategorytf.setText(tabc.getItems().get(row).toStringNameCategory());
descriptioncategorytf.setText(tabc.getItems().get(row).toStringDescriptionCategory());
}
}
});
  //HATEM PRODUCT
        deleteproduct.setDisable(true);
        updateproduct.setDisable(true);
        ShowPromotionproduct.setDisable(true);
        try {
            dataproduct.addAll(serP.readAll(p));
        } catch (SQLException ex) {
            Logger.getLogger(DashboardController.class.getName()).log(Level.SEVERE, null, ex);
        }
        idt.setCellValueFactory(new PropertyValueFactory<Product,Integer>("IdProduct"));
        namect.setCellValueFactory(new PropertyValueFactory<Product,String>("NameCategory"));
        namept.setCellValueFactory(new PropertyValueFactory<Product,String>("NameProduct"));
        desct.setCellValueFactory(new PropertyValueFactory<Product,String>("DescriptionProduct"));
        quantityt.setCellValueFactory(new PropertyValueFactory<Product,Integer>("QuantityProduct"));
        pricet.setCellValueFactory(new PropertyValueFactory<Product,Float>("PriceProduct"));
        promotiont.setCellValueFactory(new PropertyValueFactory<Product,Float>("Promotion"));
        idt.prefWidthProperty().bind(tabc.widthProperty().divide(100)); 
        tablep.setItems(dataproduct);
        try {
            listecat.setItems(FXCollections.observableArrayList(serP.combo()));
        } catch (SQLException ex) {
            Logger.getLogger(DashboardController.class.getName()).log(Level.SEVERE, null, ex);
        }
        tablep.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {

@Override
public void changed(ObservableValue observableValue, Object oldValue, Object newValue) {
if(tablep.getSelectionModel().getSelectedItem() != null) 
{    
    deleteproduct.setDisable(false);
        updateproduct.setDisable(false);
        ShowPromotionproduct.setDisable(false);
TableViewSelectionModel selectionModel = tablep.getSelectionModel();
ObservableList selectedCells = selectionModel.getSelectedCells();
TablePosition tablePosition = (TablePosition) selectedCells.get(0);
Object val = tablePosition.getTableColumn().getCellData(newValue);
int column = tablePosition.getColumn();
int row = tablePosition.getRow();
int x=tablep.getItems().get(row).toStringid();
String NameCategory=tablep.getItems().get(row).toStringNameCategory();
String NameProduct=tablep.getItems().get(row).toStringNameProduct();
String DescriptionProduct=tablep.getItems().get(row).toStringDescriptionProduct();
int QuantityProduct=tablep.getItems().get(row).toStringQuantityProduct();
float PriceProduct=tablep.getItems().get(row).toStringPriceProduct();
float Promotion=tablep.getItems().get(row).toStringPromotion();
nameproducttf.setText(NameProduct);
desctf.setText(DescriptionProduct);
quantitytf.setText(String.valueOf(QuantityProduct));
pricetf.setText(String.valueOf(PriceProduct));      
}

        
}
});
    }

    public void getidclient(int c) {

        String s = String.valueOf(c);

      //this.nameclient.setText(s);
    }

    @FXML
    private void moduleonclick(ActionEvent event) {
        if (event.getSource() == cust) {
            module.setText("Customers");
            //  pane.setBackground(new Background(new BackgroundFill(Color.rgb(0,0,0),CornerRadii.EMPTY,Insets.EMPTY)));
            gridcustomers.toFront();

        } else if (event.getSource() == prod) {
            module.setText("Categories");
            // pane.setBackground(new Background(new BackgroundFill(Color.rgb(0,0,50),CornerRadii.EMPTY,Insets.EMPTY)));
            gridproducts.toFront();

        } else if (event.getSource() == deliv) {
            module.setText("Deliveries");

            griddelivery.toFront();
            //  griddelivery.setBackground(new Background(new BackgroundFill(Color.rgb(255,255,255),CornerRadii.EMPTY,Insets.EMPTY)));;
        } else if (event.getSource() == events) {
            module.setText("Events");
            gridevents.toFront();
        } else if (event.getSource() == orders) {
            module.setText("Orders");
            gridorders.toFront();
        } else if (event.getSource() == news) {
            module.setText("News");
            gridnews.toFront();
        } else if (event.getSource() == ratecity) {
            module.setText("RateCity");
            gridratecity.toFront();
        } else if (event.getSource() == reclaim1) {
            module.setText("Reclaims");
            gridcontact.toFront();
        }
        else if (event.getSource() == products1 ) {
            module.setText("Products");
            gridproduct.toFront();
        }
    }

    @FXML
    private void logoutaction(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass()
                .getResource("subscribe.fxml"));

        Parent root = loader.load();

        logout.getScene().setRoot(root);
    }

    public void addf() {
        /*int c=0;
         String o= nameclient.getText();
         int i = Integer.parseInt(o);
         ServiceFidelityCard u=new ServiceFidelityCard();
         int points=0;
       
         // FidelityCard f=new FidelityCard(points,i);
       
      
         try {
         u.ajouter(f);
                   
         String status = "success";

         } catch (SQLException ex) {
         System.out.println(ex);
         }
    
         System.out.println("ha");*/

    }

    public void loaddata() {
        try {
            oblist.clear();
            ResultSet rs = con.createStatement().executeQuery("select * from  client ");

            while (rs.next()) {

                oblist.add(new Client(rs.getInt("IdClient"), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(6)));
            }
        } catch (SQLException ex) {
            System.out.println(ex);
        }
        table.setItems(oblist);
    }

    public void aff() {

        id.setCellValueFactory(new PropertyValueFactory<>("IdClient"));
        email.setCellValueFactory(new PropertyValueFactory<>("EmailClient"));
        name.setCellValueFactory(new PropertyValueFactory<>("name"));
        lastname.setCellValueFactory(new PropertyValueFactory<>("LastName"));
        //  id.setCellValueFactory(new PropertyValueFactory<>("Password"));
        adress.setCellValueFactory(new PropertyValueFactory<>("Adress"));

    }

    @FXML
    public void delete(ActionEvent event) throws SQLException {

        ServiceClient sc = new ServiceClient();
        Client c = (Client) table.getSelectionModel().getSelectedItem();
        //System.out.println(c.getEmailClient());

        sc.delete(c);

        aff();
        loaddata();

    }

    @FXML
    public void filter() {
        // Wrap the ObservableList in a FilteredList (initially display all data).
        FilteredList<Client> filteredData = new FilteredList<>(oblist, b -> true);

        // 2. Set the filter Predicate whenever the filter changes.
        filter.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredData.setPredicate(Client -> {
				// If filter text is empty, display all persons.

                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }

                // Compare first name and last name of every person with filter text.
                String lowerCaseFilter = newValue.toLowerCase();

                if (Client.getEmailClient().toLowerCase().indexOf(lowerCaseFilter) != -1) {
                    return true; // Filter matches first name.
                } else if (Client.getName().toLowerCase().indexOf(lowerCaseFilter) != -1) {
                    return true; // Filter matches last name.
                } else if (String.valueOf(Client.getLastName()).indexOf(lowerCaseFilter) != -1) {
                    return true;
                } else {
                    return false; // Does not match.
                }
            });
        });

        // 3. Wrap the FilteredList in a SortedList. 
        SortedList<Client> sortedData = new SortedList<>(filteredData);

		// 4. Bind the SortedList comparator to the TableView comparator.
        // 	  Otherwise, sorting the TableView would have no effect.
        sortedData.comparatorProperty().bind(table.comparatorProperty());

        // 5. Add sorted (and filtered) data to the table.
        table.setItems(sortedData);
    }

    public void afficherdeliverycrue() throws SQLException {

        /*try {
         ServiceDeliveryMan serD = new ServiceDeliveryMan();
         oblist.clear();
         data.addAll(serD.readAll());
         idtb.setCellValueFactory(new PropertyValueFactory<>("id"));
         nametb.setCellValueFactory(new PropertyValueFactory<>("firstname"));
         lastnametb.setCellValueFactory(new PropertyValueFactory<>("lastname"));
         addresstb.setCellValueFactory(new PropertyValueFactory<>("address"));
         emailtb.setCellValueFactory(new PropertyValueFactory<>("email"));
         phonetb.setCellValueFactory(new PropertyValueFactory<>("phonenumber"));
         availabletb.setCellValueFactory(new PropertyValueFactory<>("Available"));
         scoretb.setCellValueFactory(new PropertyValueFactory<>("Score"));
         nbscoretb.setCellValueFactory(new PropertyValueFactory<>("numberscore"));
         tableDD.setItems(data);
         } catch (SQLException ex) {
         System.out.println(ex);
         }*/
    }

    public boolean controleSaisie() throws IOException, SQLException {
        boolean saisie = true;

        if (!Validation.textValidation(nameD, namelabel)) {
            saisie = false;
        } else {
            namelabel.setText("");
        }
        if (!Validation.textValidation(lastnameD, lastnamelabel)) {
            saisie = false;
        } else {
            lastnamelabel.setText("");
        }
        if (!Validation.textValidation(addressD, addresslabel)) {
            saisie = false;
        } else {
            addresslabel.setText("");
        }
        if (!Validation.texMail(emailD, emaillabel, "Verify your Email")) {
            saisie = false;
        } else {
            emaillabel.setText("");
        }
        if (!Validation.texAlphNum(phoneD, phonelabel, "Verify your Phone Number")) {
            saisie = false;
        } else {
            phonelabel.setText("");
        }

        return saisie;
    }

    @FXML
    private void deleteaction(ActionEvent event) throws SQLException {

        ServiceDeliveryMan serD = new ServiceDeliveryMan();

        TableViewSelectionModel selectionModel = tableDD.getSelectionModel();
        ObservableList selectedCells = selectionModel.getSelectedCells();
        if (selectedCells.size() == 0) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Deleting Delivery Man");
            alert.setHeaderText("Select a Delivery Man");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK) {
                alert.close();
            }
        } else {
            TablePosition tablePosition = (TablePosition) selectedCells.get(0);
            int row = tablePosition.getRow();
            int x = tableDD.getItems().get(row).toStringID();
            serD.delete1(x);
            data.clear();
            afficherdelivery();
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Deleting Delivery Man");
            alert.setHeaderText("A Delivery Man succesfuly Deleted");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK) {
                alert.close();
            }
        }

    }

    public void loaddelivery() {

    }

    @FXML
    private void addaction(ActionEvent event) throws IOException, SQLException {

        if (controleSaisie() == true) {
            try {

                String name = nameD.getText();
                String lastname = lastnameD.getText();
                String address = addressD.getText();
                String email = emailD.getText();
                int phone = Integer.parseInt(phoneD.getText());
                String a = "Yes";
                DeliveryMan d = new DeliveryMan(name, lastname, address, email, phone, a);
                ServiceDeliveryMan serD = new ServiceDeliveryMan();
                serD.add(d);
                data.clear();
                afficherdelivery();

            } catch (SQLException ex) {
                System.out.println(ex);
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Add Delivery Man");
            alert.setHeaderText("3abi les champs");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK) {
                alert.close();
            }
        }
    }

    public void afficherdelivery() throws SQLException {

        ServiceDeliveryMan serD = new ServiceDeliveryMan();
        data.addAll(serD.readAll2());

        nametb.setCellValueFactory(new PropertyValueFactory<DeliveryMan, String>("firstname"));
        lastnametb.setCellValueFactory(new PropertyValueFactory<DeliveryMan, String>("lastname"));
        addresstb.setCellValueFactory(new PropertyValueFactory<DeliveryMan, String>("address"));
        emailtb.setCellValueFactory(new PropertyValueFactory<DeliveryMan, String>("email"));
        phonetb.setCellValueFactory(new PropertyValueFactory<DeliveryMan, Integer>("phonenumber"));
        availabletb.setCellValueFactory(new PropertyValueFactory<DeliveryMan, String>("available"));
        scoretb.setCellValueFactory(new PropertyValueFactory<DeliveryMan, Float>("score"));
        nbscoretb.setCellValueFactory(new PropertyValueFactory<DeliveryMan, Float>("numberscore"));

        tableDD.setItems(data);

    }

    public void afficherfidelity() throws SQLException {

        ServiceFidelityCard serD = new ServiceFidelityCard();
        fidelitytable.addAll(serD.readAllf());

        Idproduct.setCellValueFactory(new PropertyValueFactory<>("IdFidelityCard"));
        Points.setCellValueFactory(new PropertyValueFactory<>("Points"));
        Idclient.setCellValueFactory(new PropertyValueFactory<>("IdClient"));

        tablefidelity.setItems(fidelitytable);

    }
     public void afficherorder() throws SQLException {

        ServiceOrderp serD = new ServiceOrderp();
      order.addAll(serD.readAllo());

       idcliento.setCellValueFactory(new PropertyValueFactory<>("IdClient"));
       emailcliento.setCellValueFactory(new PropertyValueFactory<>("EmailClient"));
        phonenumbero.setCellValueFactory(new PropertyValueFactory<>("PhoneNumber"));
       paymento.setCellValueFactory(new PropertyValueFactory<>("PaymentMethod"));
        totaleo.setCellValueFactory(new PropertyValueFactory<>("TotalO"));
       

        tableorders.setItems(order);

       
    }

    @FXML
    private void updateaction(ActionEvent event) throws SQLException {

        TableViewSelectionModel selectionModel = tableDD.getSelectionModel();
        ObservableList selectedCells = selectionModel.getSelectedCells();
        if (selectedCells.size() == 0) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Updating Delivery Man");
            alert.setHeaderText("Select a Delivery Man");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK) {
                alert.close();
            }
        } else {
            String FirstName = nameD.getText();
            String LastName = lastnameD.getText();
            String Address = addressD.getText();
            String emaild = emailD.getText();
            int phonedd = Integer.parseInt(phoneD.getText());
            DeliveryMan d = new DeliveryMan(FirstName, LastName, Address, emaild, phonedd);
            ServiceDeliveryMan serD = new ServiceDeliveryMan();
            TablePosition tablePosition = (TablePosition) selectedCells.get(0);
            int row = tablePosition.getRow();
            int x = tableDD.getItems().get(row).toStringID();
            serD.updateN(d, x);
            data.clear();
            afficherdelivery();
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Updating Delivery Man");
            alert.setHeaderText("A Delivery Man succesfuly updated");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK) {
                alert.close();
            }
        }

    }

    @FXML
    public void fillfields() {
        DeliveryMan c = (DeliveryMan) tableDD.getSelectionModel().getSelectedItem();

        nameD.setText(c.getFirstname());
        lastnameD.setText(c.getLastname());
        addressD.setText(c.getAddress());
        emailD.setText(c.getEmail());
        phoneD.setText(String.valueOf(c.getPhonenumber()));
    }

    @FXML
    private void resetaction(ActionEvent event) {
        nameD.setText("");
        lastnameD.setText("");
        addressD.setText("");
        emailD.setText("");
        phoneD.setText("");
    }

    @FXML
    private void pdfaction(ActionEvent event) {
    }

    @FXML
    private void updatecity(ActionEvent event) throws SQLException {
        ServiceRateCity serD = new ServiceRateCity();

        TableViewSelectionModel selectionModel = tablerate.getSelectionModel();
        ObservableList selectedCells = selectionModel.getSelectedCells();
        if (selectedCells.size() == 0) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Updating Rate City");
            alert.setHeaderText("Select a City");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK) {
                alert.close();
            }
        } else {
            float ratenew = Float.parseFloat(newrate.getText());
            TablePosition tablePosition = (TablePosition) selectedCells.get(0);
            int row = tablePosition.getRow();
            String x = tablerate.getItems().get(row).toString2();
            serD.updateN(ratenew, x);

            for (int i = 0; i < tablerate.getItems().size(); i++) {
                tablerate.getItems().clear();
            }
            dataR.addAll(serD.readAll());
            rate.setCellValueFactory(new PropertyValueFactory<ratecity, Float>("Rate"));

            tablerate.setItems(dataR);
        }

    }

    @FXML
    private void upload(ActionEvent event) {
        FileChooser fc = new FileChooser();
        String imageFile = "";
        File f = fc.showOpenDialog(null);

        if (f != null) {
            imageFile = f.getName();
            txtimage1.setText(imageFile);
        }
    }

    @FXML
    private void deleteAction(ActionEvent event) throws SQLException {
        Serviceevenement serE = new Serviceevenement();
        if (Eventtv1.getSelectionModel().getSelectedItem() != null) {
            Alert deleteEventAlert = new Alert(Alert.AlertType.CONFIRMATION);
            deleteEventAlert.setTitle("Delete Event");
            deleteEventAlert.setHeaderText(null);
            deleteEventAlert.setContentText("Are you sure want to delete this Event ?");
            Optional<ButtonType> optionDeleteBookAlert = deleteEventAlert.showAndWait();
            if (optionDeleteBookAlert.get() == ButtonType.OK) {
                Evenement e = Eventtv1.getSelectionModel().getSelectedItem();
                serE.delete(e);
                dataE.clear();
                dataE.addAll(serE.readAll1());
                //Alert Delete Blog :
                Alert succDeleteEventAlert = new Alert(Alert.AlertType.INFORMATION);
                succDeleteEventAlert.setTitle("Delete Event");
                succDeleteEventAlert.setHeaderText("Results:");
                succDeleteEventAlert.setContentText("Event deleted successfully!");

                succDeleteEventAlert.showAndWait();
            } else if (optionDeleteBookAlert.get() == ButtonType.CANCEL) {

            }

        } else {

            //Alert Select BOOK :
            Alert selectBookAlert = new Alert(Alert.AlertType.WARNING);
            selectBookAlert.setTitle("Select a Event");
            selectBookAlert.setHeaderText(null);
            selectBookAlert.setContentText("You need to select event first!");
            selectBookAlert.showAndWait();
            //Alert Select Book !

        }
    }

    private void changeAdressCellEvent(CellEditEvent edittedCell) {

        Evenement LivreSelected = Eventtv1.getSelectionModel().getSelectedItem();
        LivreSelected.setAddressEvent(edittedCell.getNewValue().toString());

    }

    private void changePriceCellEvent(CellEditEvent edittedCell) {
        Evenement LivreSelected = Eventtv1.getSelectionModel().getSelectedItem();
        LivreSelected.setPriceEvent(Float.parseFloat(edittedCell.getNewValue().toString()));

    }

    private void changenbrplaceCellEvent(CellEditEvent edittedCell) {

        Evenement LivreSelected = Eventtv1.getSelectionModel().getSelectedItem();
        LivreSelected.setNbrplace(Integer.parseInt(edittedCell.getNewValue().toString()));
    }

    private void changeimageCellEvent(CellEditEvent edittedCell) {

        Evenement LivreSelected = Eventtv1.getSelectionModel().getSelectedItem();
        LivreSelected.setImage(edittedCell.getNewValue().toString());

    }

    private void changedateDCellEvent(CellEditEvent edittedCell) {

        Evenement LivreSelected = Eventtv1.getSelectionModel().getSelectedItem();
        LivreSelected.setDateD(Timestamp.valueOf((edittedCell.getNewValue().toString())));

    }

    private void changedateFCellEvent(CellEditEvent edittedCell) {

        Evenement LivreSelected = Eventtv1.getSelectionModel().getSelectedItem();
        LivreSelected.setDateF(Timestamp.valueOf((edittedCell.getNewValue().toString())));

    }

    @FXML
    private void editAction(ActionEvent event) {
        Serviceevenement serE = new Serviceevenement();
        if (Eventtv1.getSelectionModel().getSelectedItem() != null) {

            Evenement l = Eventtv1.getSelectionModel().getSelectedItem();

            try {
                serE.updateEvent(l);
            } catch (SQLException ex) {
                Logger.getLogger(DashboardController.class.getName()).log(Level.SEVERE, null, ex);
            }
            Alert EventAlert = new Alert(Alert.AlertType.INFORMATION);
            EventAlert.setTitle("edit");
            EventAlert.setHeaderText(null);
            EventAlert.setContentText("event was succfuly edit");
            EventAlert.showAndWait();

        } else {
            //Alert Select BOOK :
            Alert selectEventAlert = new Alert(Alert.AlertType.WARNING);
            selectEventAlert.setTitle("Select an event");
            selectEventAlert.setHeaderText(null);
            selectEventAlert.setContentText("You need to select an event first!");
            selectEventAlert.showAndWait();
            //Alert Select Book !
        }
    }

    @FXML
    private void select(ActionEvent event) {
    }

    @FXML
    private void addevent(ActionEvent event) throws SQLException {
        if (combotype1.getSelectionModel().isEmpty()) {
            Alert selectEventAlert = new Alert(Alert.AlertType.WARNING);
            selectEventAlert.setTitle("Select an event");
            selectEventAlert.setHeaderText(null);
            selectEventAlert.setContentText("You need to select a type !");
            selectEventAlert.showAndWait();
            return;
        }

        Timestamp dated = Timestamp.valueOf(combodateD1.getValue().atTime(LocalTime.MIDNIGHT));

        Timestamp datef = Timestamp.valueOf(combodateF1.getValue().atTime(LocalTime.MIDNIGHT));

        Evenement e = new Evenement(txtname1.getText(), txtaddress1.getText(), (String) combotype1.getValue(), Float.parseFloat(txtprice1.getText()), Integer.parseInt(txtnumber1.getText()), txtdescription1.getText(), txtimage1.getText(), dated, datef);
        Serviceevenement serE = new Serviceevenement();
        serE.add(e);

        Alert succAddBookAlert = new Alert(Alert.AlertType.INFORMATION);
        succAddBookAlert.setTitle("Add Event");
        succAddBookAlert.setHeaderText("Results:");
        succAddBookAlert.setContentText("Event added successfully!");
        succAddBookAlert.showAndWait();
        dataE.clear();
        dataE.addAll(serE.readAll1());
    }

    private void filter(ActionEvent event) throws SQLException {
        Serviceevenement serE = new Serviceevenement();
        dataE.clear();
        // System.out.println("heyy yuuu");
        dataE.addAll(serE.readAll1().stream().filter((art)
                -> art.getNameEvent().toLowerCase().contains(searchTF1.getText().toLowerCase())
                || art.getAddressEvent().toLowerCase().contains(searchTF1.getText().toLowerCase())
                || art.getDescriptionEvent().toLowerCase().contains(searchTF1.getText().toLowerCase())
                || art.getType().toLowerCase().contains(searchTF1.getText().toLowerCase())
        //                || Integer.toString(art.getPrixAchat()).equals(searchTF.getText())
        //                || Integer.toString(art.getPrixVente()).equals(searchTF.getText())

        ).collect(Collectors.toList()));
    }

    @FXML
    private void AddNewss(MouseEvent event) {
        boolean isSubjectEmpty = TextFieldValidation.isTextFieldNotEmpty(Subjecttfx, erreur_subject, "Subject is Empty!");
        boolean isPhotoEmpty = TextFieldValidation.isTextFieldNotEmpty(Photoofx, erreur_photo, "Photo is Empty!");
        boolean isTextEmpty = TextFieldValidation.isTextFieldNotEmpty(Texttfx, erreur_text, "Text is Empty!");

        Validation.textValidation(filter);
        if (isSubjectEmpty && isPhotoEmpty && isTextEmpty) {
            String Subjectn = Subjecttfx.getText();
            String Photom = Photoofx.getText();
            String Textm = Texttfx.getText();

            LocalDate datemm = Datepickerfx.getValue();
            java.sql.Timestamp tm = java.sql.Timestamp.valueOf(datemm.atStartOfDay());

            try {
                ServiceInfo srv = new ServiceInfo();
                Information info1 = new Information(Subjectn, Textm, tm, Photom);
                srv.add(info1);
                setCellTbale();
                LoadDataFromDB();
                AlertDialog.display("Info", "Done!");
            } catch (SQLException e) {

            }
        }
    }

    private void setCellValueFromTableToTextFiled() {
        tablenews.setOnMouseClicked(e -> {
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
            Information inf1 = tablenews.getItems().get(tablenews.getSelectionModel().getSelectedIndex());
            String string1 = dateFormat.format(inf1.getDate());
            Subjecttfx.setText(inf1.getSubject());

            Texttfx.setText(inf1.getText());
            Photoofx.setText(inf1.getPhoto());
        });
    }

    private void setCellTbale() {

        ColumnSubject.setCellValueFactory(new PropertyValueFactory<>("Subject"));
        ColumnDate.setCellValueFactory(new PropertyValueFactory<>("Date"));
        ColumnPhoto.setCellValueFactory(new PropertyValueFactory<>("Photo"));
        ColumnText.setCellValueFactory(new PropertyValueFactory<>("Text"));

    }

    private void LoadDataFromDB() {
        data.clear();
        ServiceInfo ser = new ServiceInfo();
        try {
            data1 = FXCollections.observableArrayList();
            data1 = ser.readAll();
        } catch (Exception e) {
        }

        tablenews.setItems(data1);
    }

    private void searchNews() {
        // Wrap the ObservableList in a FilteredList (initially display all data).
        FilteredList<Information> filteredData = new FilteredList<>(data1, b -> true);

        // 2. Set the filter Predicate whenever the filter changes.
        SearchNewsfx.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredData.setPredicate(Information -> {
				// If filter text is empty, display all persons.

                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }

                // Compare first name and last name of every person with filter text.
                String lowerCaseFilter = newValue.toLowerCase();

                if (Information.getSubject().toLowerCase().indexOf(lowerCaseFilter) != -1) {
                    return true; // Filter matches first name.
                } else {
                    return false; // Does not match.
                }
            });
        });

        // 3. Wrap the FilteredList in a SortedList. 
        SortedList<Information> sortedData = new SortedList<>(filteredData);

		// 4. Bind the SortedList comparator to the TableView comparator.
        // 	  Otherwise, sorting the TableView would have no effect.
        sortedData.comparatorProperty().bind(tablenews.comparatorProperty());

        // 5. Add sorted (and filtered) data to the table.
        tablenews.setItems(sortedData);
    }

    @FXML
    private void UpdateNews(MouseEvent event) {
        boolean isSubjectEmpty = TextFieldValidation.isTextFieldNotEmpty(Subjecttfx, erreur_subject, "Subject is Empty!");
        boolean isPhotoEmpty = TextFieldValidation.isTextFieldNotEmpty(Photoofx, erreur_photo, "Photo is Empty!");
        boolean isTextEmpty = TextFieldValidation.isTextFieldNotEmpty(Texttfx, erreur_text, "Text is Empty!");
       // boolean isDateValid = Validation.TextFieldValidation.isDateFormatValid(Dateefx, erreur_date, "Date Format Must be yyyy-MM-dd HH:mm:ss.SSSSS!");

        if (isSubjectEmpty && isPhotoEmpty && isTextEmpty) {

            String Subjectn = Subjecttfx.getText();
            String Photom = Photoofx.getText();
            String Textm = Texttfx.getText();

            LocalDate datemm = Datepickerfx.getValue();
            java.sql.Timestamp tm = java.sql.Timestamp.valueOf(datemm.atStartOfDay());

            try {
                ServiceInfo srv = new ServiceInfo();
                Information info1 = new Information(Subjectn, Textm, tm, Photom);
                srv.update(info1);
                setCellTbale();
                LoadDataFromDB();
                AlertDialog.display("Info", "Done!");
            } catch (SQLException e) {
            }
        }

    }

    @FXML
    private void DeleteNews(MouseEvent event) throws SQLException {
        boolean isSubjectEmpty = TextFieldValidation.isTextFieldNotEmpty(Subjecttfx, erreur_subject, "Subject is Empty!");
        Information c = (Information) tablenews.getSelectionModel().getSelectedItem();

        ServiceInfo srv = new ServiceInfo();
        srv.delete(c);
        setCellTbale();
        LoadDataFromDB();
        AlertDialog.display("Info", "Done!");

    }

    @FXML
    private void SendEmailContact(MouseEvent event) {

        String text = EmailContactfx.getText();
        String mail = ClientIdContactfx.getText();
        Mail m = new Mail();
        m.envoyer(mail, text);

    }

    private void setCellTbalecontact() {

        ClientIdColumn.setCellValueFactory(new PropertyValueFactory<>("IdClient"));
        ContactColumn.setCellValueFactory(new PropertyValueFactory<>("text"));

    }

    private void LoadDataFromDBcontact() {
        Contact1.clear();

        try {
            ste = con.prepareStatement("Select * from contact");
            rs = ste.executeQuery();
            while (rs.next()) {
                Contact1.add(new Contact(rs.getInt(2), rs.getString(3)));
            }

        } catch (SQLException e) {
        }
        TableContact.setItems(Contact1);
    }

    // Hatem Category
    @FXML
    private void resaction(ActionEvent event) {
        namecategorytf.setText("");
        descriptioncategorytf.setText("");
    }

    @FXML
    private void promotioncat(ActionEvent event) throws SQLException {
        TableViewSelectionModel selectionModel = tabc.getSelectionModel();
                ObservableList selectedCells = selectionModel.getSelectedCells();
                    TablePosition tablePosition = (TablePosition) selectedCells.get(0);
                int row = tablePosition.getRow();
                String x=tabc.getItems().get(row).toStringNameCategory();
                float p=Float.parseFloat(promo.getText());
                  serC.promotionCat(x,p);
                  Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Promotion in Category");
        alert.setHeaderText("Promotion Done");
        Optional<ButtonType> result = alert.showAndWait();
    }

    @FXML
    private void quantitycategory(ActionEvent event) throws SQLException {
        tabc.getItems().clear();
        datacategory2.addAll(serC.readQ());
        idc.setCellValueFactory(new PropertyValueFactory<Category,Integer>("IdCategory"));
           namec.setCellValueFactory(new PropertyValueFactory<Category,String>("NameCategory"));
            desc.setCellValueFactory(new PropertyValueFactory<Category,String>("DescriptionCategory"));
            totalCategory.setCellValueFactory(new PropertyValueFactory<Category,Integer>("total"));
                idc.prefWidthProperty().bind(tabc.widthProperty().divide(100)); 
            tabc.setItems(datacategory2);
    }

    @FXML
    private void returntablecategory(ActionEvent event) throws SQLException {
        tabc.getItems().clear();
        datacategory.addAll(serC.readAll(c));
        idc.setCellValueFactory(new PropertyValueFactory<Category,Integer>("IdCategory"));
           namec.setCellValueFactory(new PropertyValueFactory<Category,String>("NameCategory"));
            desc.setCellValueFactory(new PropertyValueFactory<Category,String>("DescriptionCategory"));
           // totalCategory.setCellValueFactory(new PropertyValueFactory<Category,Integer>("total"));
            //totalCategory.prefWidthProperty().bind(tabc.widthProperty().divide(100)); 
          idc.prefWidthProperty().bind(tabc.widthProperty().divide(100)); 
           tabc.setItems(datacategory);
    }

    @FXML
    private void excelcategoryquantity(ActionEvent event) throws SQLException {
        datacategory2.addAll(serC.readQ());
       try {
           XSSFWorkbook wb = new XSSFWorkbook();//for earlier version use HSSF
                
                XSSFSheet sheet = wb.createSheet("Category Details");
                
                XSSFRow header = sheet.createRow(0);
                
                header.createCell(0).setCellValue("Name Category");
                
                header.createCell(1).setCellValue("Description Category");
                
                header.createCell(2).setCellValue("Quantity");
                
                
                
                
                sheet.autoSizeColumn(1);
                
                sheet.autoSizeColumn(2);
                
                sheet.setColumnWidth(3, 256*25);//256-character width
                
                
                
                sheet.setZoom(150);//scale-150%
                int index = 1;
                for (int i=0;i<datacategory2.size();i++)
                {
                     XSSFRow row = sheet.createRow(index);
                    
                    row.createCell(0).setCellValue(datacategory2.get(i).getNameCategory());
                    
                    row.createCell(1).setCellValue(datacategory2.get(i).getDescriptionCategory());
                    
                    row.createCell(2).setCellValue(datacategory2.get(i).getTotal());

                    index++;
                }
                 try (FileOutputStream fileOut = new FileOutputStream("CategoriesQuantity.xlsx") // before 2007 version xls
                        ) {
                    wb.write(fileOut);
                }
                 Alert alert = new Alert(AlertType.INFORMATION);
                
                alert.setTitle("Information Dialog");
                
                alert.setHeaderText(null);
                
                alert.setContentText("Categories Details Exported in Excel Sheet.");
                
                alert.showAndWait();
    } catch (FileNotFoundException ex) {
                
                System.out.println("Error " + ex.getMessage());
                
            } catch (IOException ex) {
                
                System.out.println("Error " + ex.getMessage());
                
            }
                
                
     
    }

    @FXML
    private void add1action(ActionEvent event) throws SQLException {
        if (controlesaisieCAT()==true)
        {
            String CategoryName = namecategorytf.getText();
            String Desc = descriptioncategorytf.getText();
            Category c = new Category(CategoryName,Desc);
            serC.add(c);
           for ( int i = 0; i<tabc.getItems().size(); i++) {
    tabc.getItems().clear();
}
            datacategory.addAll(serC.readAll(c));
            idc.setCellValueFactory(new PropertyValueFactory<Category,Integer>("IdCategory"));
            namec.setCellValueFactory(new PropertyValueFactory<Category,String>("NameCategory"));
             desc.setCellValueFactory(new PropertyValueFactory<Category,String>("DescriptionCategory"));
             tabc.setItems(datacategory);  
        }
    }

    @FXML
    private void update2action(ActionEvent event) throws SQLException {
        String catname=namecategorytf.getText();
                String descategory=descriptioncategorytf.getText();
                
                TableViewSelectionModel selectionModel = tabc.getSelectionModel();
                ObservableList selectedCells = selectionModel.getSelectedCells();
                TablePosition tablePosition = (TablePosition) selectedCells.get(0);
                int row = tablePosition.getRow();
                int x=tabc.getItems().get(row).toString1();
                Category c = new Category(x,catname,descategory);
                serC.update(c);
         for ( int i = 0; i<tabc.getItems().size(); i++) {
    tabc.getItems().clear();
}
            datacategory.addAll(serC.readAll(c));
            idc.setCellValueFactory(new PropertyValueFactory<Category,Integer>("IdCategory"));
            namec.setCellValueFactory(new PropertyValueFactory<Category,String>("NameCategory"));
             desc.setCellValueFactory(new PropertyValueFactory<Category,String>("DescriptionCategory"));
              
             tabc.setItems(datacategory);
    }

    @FXML
    private void delete2action(ActionEvent event) throws SQLException {
        TableViewSelectionModel selectionModel = tabc.getSelectionModel();
                ObservableList selectedCells = selectionModel.getSelectedCells();
                TablePosition tablePosition = (TablePosition) selectedCells.get(0);
                int row = tablePosition.getRow();
                int x=tabc.getItems().get(row).toString1();
                Category c=new Category(x);
                serC.delete(c);
                 for ( int i = 0; i<tabc.getItems().size(); i++) {
    tabc.getItems().clear();
}
            datacategory.addAll(serC.readAll(c));
            idc.setCellValueFactory(new PropertyValueFactory<Category,Integer>("IdCategory"));
            namec.setCellValueFactory(new PropertyValueFactory<Category,String>("NameCategory"));
             desc.setCellValueFactory(new PropertyValueFactory<Category,String>("DescriptionCategory"));
              
             tabc.setItems(datacategory);
             
    }

    @FXML
    private void addproductaction(ActionEvent event) throws SQLException {
        String NameProduct = nameproducttf.getText();
            String DescriptionProduct = desctf.getText();
           int QuantityProduct = Integer.parseInt(quantitytf.getText());
            float PriceProduct = Float.parseFloat(pricetf.getText());
            String NameCategory = listecat.getSelectionModel().getSelectedItem().toString();
                Product p=new Product(NameCategory, NameProduct, DescriptionProduct, QuantityProduct, PriceProduct);
                serP.add(p);
                for ( int i = 0; i<tablep.getItems().size(); i++) {
    tablep.getItems().clear();
}
     dataproduct.addAll(serP.readAll(p));  
      idt.setCellValueFactory(new PropertyValueFactory<Product,Integer>("IdProduct"));
        namept.setCellValueFactory(new PropertyValueFactory<Product,String>("NameProduct"));
        desct.setCellValueFactory(new PropertyValueFactory<Product,String>("DescriptionProduct"));
        quantityt.setCellValueFactory(new PropertyValueFactory<Product,Integer>("QuantityProduct"));
        pricet.setCellValueFactory(new PropertyValueFactory<Product,Float>("PriceProduct"));
        promotiont.setCellValueFactory(new PropertyValueFactory<Product,Float>("Promotion"));
        listecat.getSelectionModel().select(-1);
        tablep.setItems(dataproduct);
    }

    @FXML
    private void deleteproductaction(ActionEvent event) throws SQLException {
        TableViewSelectionModel selectionModel = tablep.getSelectionModel();
                ObservableList selectedCells = selectionModel.getSelectedCells();
                TablePosition tablePosition = (TablePosition) selectedCells.get(0);
                int row = tablePosition.getRow();
                  int x=tablep.getItems().get(row).toStringid();
                  Product p= new Product(x);
                serP.delete(p);
                 for ( int i = 0; i<tablep.getItems().size(); i++) {
    tablep.getItems().clear();
}
             dataproduct.addAll(serP.readAll(p));
           idt.setCellValueFactory(new PropertyValueFactory<Product,Integer>("IdProduct"));
        namect.setCellValueFactory(new PropertyValueFactory<Product,String>("NameCategory"));
        namept.setCellValueFactory(new PropertyValueFactory<Product,String>("NameProduct"));
        desct.setCellValueFactory(new PropertyValueFactory<Product,String>("DescriptionProduct"));
        quantityt.setCellValueFactory(new PropertyValueFactory<Product,Integer>("QuantityProduct"));
        pricet.setCellValueFactory(new PropertyValueFactory<Product,Float>("PriceProduct"));
        promotiont.setCellValueFactory(new PropertyValueFactory<Product,Float>("Promotion"));
        tablep.setItems(dataproduct);   
                 
    }

    @FXML
    private void updateproductaction(ActionEvent event) throws SQLException {
        String NameCategory = listecat.getSelectionModel().getSelectedItem().toString();
            String NameProduct = nameproducttf.getText();
            String DescriptionProduct = desctf.getText();
           int QuantityProduct = Integer.parseInt(quantitytf.getText());
            float PriceProduct = Float.parseFloat(pricetf.getText());
            float Promotion = Float.parseFloat(promotiontf.getText()); 
            TableViewSelectionModel selectionModel = tablep.getSelectionModel();
        ObservableList selectedCells = selectionModel.getSelectedCells();
        TablePosition tablePosition = (TablePosition) selectedCells.get(0);
        int row = tablePosition.getRow();
        int x=tablep.getItems().get(row).toStringid();
         Product p=new Product (x, NameCategory, NameProduct, DescriptionProduct, QuantityProduct, PriceProduct, Promotion);
        serP.update(p);
        for ( int i = 0; i<tablep.getItems().size(); i++) {
    tablep.getItems().clear();
            }
        dataproduct.addAll(serP.readAll(p));
           idt.setCellValueFactory(new PropertyValueFactory<Product,Integer>("IdProduct"));
        namect.setCellValueFactory(new PropertyValueFactory<Product,String>("NameCategory"));
        namept.setCellValueFactory(new PropertyValueFactory<Product,String>("NameProduct"));
        desct.setCellValueFactory(new PropertyValueFactory<Product,String>("DescriptionProduct"));
        quantityt.setCellValueFactory(new PropertyValueFactory<Product,Integer>("QuantityProduct"));
        pricet.setCellValueFactory(new PropertyValueFactory<Product,Float>("PriceProduct"));
        promotiont.setCellValueFactory(new PropertyValueFactory<Product,Float>("Promotion"));
         listecat.getSelectionModel().select(-1);
        tablep.setItems(dataproduct);
        } 
    

    @FXML
    private void Resetproduct(ActionEvent event) {
       nameproducttf.setText("");
        desctf.setText("");
        quantitytf.setText("");
        pricetf.setText("");
       promotiontf.setText("");
    }

    @FXML
    private void ShowPromotionproduct(ActionEvent event) {
        
    }

    @FXML
    private void LocationStatsproduct(ActionEvent event) {
    }


    @FXML
    private void UploadPic(ActionEvent event) {
    }

    @FXML
    private void pdfproductaction(ActionEvent event) throws SQLException {
        Product p = new Product();
        dataproduct.addAll(serP.readAll(p));
       try {
           XSSFWorkbook wb = new XSSFWorkbook();//for earlier version use HSSF
                
                XSSFSheet sheet = wb.createSheet("Product Details");
                
                XSSFRow header = sheet.createRow(0);
                
                header.createCell(0).setCellValue("Name Category");
                
                header.createCell(1).setCellValue("Name Product");
                
                header.createCell(2).setCellValue("Description Product");
                
                header.createCell(3).setCellValue("Quantity Product");
                
                header.createCell(4).setCellValue("Price Product");
                
                header.createCell(5).setCellValue("Promotion");
                sheet.autoSizeColumn(1);
                
                sheet.autoSizeColumn(2);
                
                sheet.setColumnWidth(3, 256*25);//256-character width
                
                
                
                sheet.setZoom(150);//scale-150%
                int index = 1;
                for (int i=0;i<dataproduct.size();i++)
                {
                     XSSFRow row = sheet.createRow(index);
                    
                    row.createCell(0).setCellValue(dataproduct.get(i).getNameCategory());
                    
                    row.createCell(1).setCellValue(dataproduct.get(i).getNameProduct());
                    
                    row.createCell(2).setCellValue(dataproduct.get(i).getDescriptionProduct());
                    
                    row.createCell(3).setCellValue(dataproduct.get(i).getQuantityProduct());
                    
                    row.createCell(4).setCellValue(dataproduct.get(i).getPriceProduct());
                    
                    row.createCell(5).setCellValue(dataproduct.get(i).getPromotion());

                    index++;
                }
                 try (FileOutputStream fileOut = new FileOutputStream("ProductDetails.xlsx") // before 2007 version xls
                        ) {
                    wb.write(fileOut);
                }
                 Alert alert = new Alert(AlertType.INFORMATION);
                
                alert.setTitle("Information Dialog");
                
                alert.setHeaderText(null);
                
                alert.setContentText("Product Details Exported in Excel Sheet.");
                
                alert.showAndWait();
    } catch (FileNotFoundException ex) {
                
                System.out.println("Error " + ex.getMessage());
                
            } catch (IOException ex) {
                
                System.out.println("Error " + ex.getMessage());
                
            }
                
    }
}
