/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import Service.ServiceClient;
import entities.Client;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;

/**
 * FXML Controller class
 *
 * @author asus
 */
public class SignupController implements Initializable {
    @FXML
    private TextField email;
    @FXML
    private TextField name;
    @FXML
    private TextField lastname;
    @FXML
    private TextField password;
    @FXML
    private TextField repeated;
    @FXML
    private TextField address;
    @FXML
    private Button add;
    @FXML
    private Label label;
    @FXML
    private Button bk;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void addclient(ActionEvent event) {
         String em = email.getText();
        String nm = name.getText();
        String lnm = lastname.getText();
        String pw = password.getText();

        String ad = address.getText();
        String rp = repeated.getText();

        if (em.isEmpty() || nm.isEmpty() || lnm.isEmpty()
                || pw.isEmpty() || ad.isEmpty() || rp.isEmpty()) {

            setLblError(Color.TOMATO, "Empty credentials");
            String status = "Error";
        } else if (pw.contentEquals(rp)) {

            ServiceClient sp = new ServiceClient();
            if (sp.checkmail(em) == false) {
                Client p = new Client(em, nm, lnm, pw, ad);
                try {
                    sp.add(p);
                    setLblError(Color.BLUE, "you have just created your account !");
                    String status = "success";

                } catch (SQLException ex) {
                    System.out.println(ex);
                }
            } else {
                setLblError(Color.TOMATO, "Email already exists");
                String status = "Error";
            }
        } else {
            setLblError(Color.TOMATO, "password and repeated password fields must be identical");
            String status = "Error";

        }
    }

    @FXML
    private void back(ActionEvent event) throws IOException {
         FXMLLoader loader = new FXMLLoader(getClass()
                .getResource("signinfront.fxml"));

        Parent root = loader.load();

       bk.getScene().setRoot(root);
    }

    @FXML
    private void back(MouseEvent event) {
    }
    
    private void setLblError(Color color, String text) {
        label.setTextFill(color);
        label.setText(text);
        System.out.println(text);
    }
}
