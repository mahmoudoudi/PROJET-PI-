/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import IService.IService;
import Utils.Database;
import entities.wishlist;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author asus
 */
public class Servicewishlist implements IService<wishlist> {

    private final Connection con;
    private Statement ste;

    public Servicewishlist() {
        con = Database.getInstance().getConnection();

    }
 @Override
    public List<wishlist> readAll(wishlist w) throws SQLException {
        List<wishlist> arr = new ArrayList<>();
        ste = con.createStatement();
        ResultSet rs = ste.executeQuery("SElECT * From  product e inner join  wishlist a on e.idProduct= a.id_p where email_c='" + w.getIdClient() + "' ");
        while (rs.next()) {

            int price = rs.getInt(1);
            String name = rs.getString(2);
            String lastname = rs.getString(3);
            String pw = rs.getString(4);
            String rpw = rs.getString(5);

            wishlist p = new wishlist(price, name);
            arr.add(p);
        }
        return arr;
    }

    @Override
    public void add(wishlist t) throws SQLException {
        ste = con.createStatement();
//        w.getCl().getEmail();
        String requeteInsert = "INSERT INTO wishlist (id_p,email_c)VALUES ( '" + t.getIdProduct() + "', '" + t.getIdClient() + "')";
        ste.executeUpdate(requeteInsert);
    }

    @Override
    public void delete(wishlist t) throws SQLException {
        ste = con.createStatement();
   // String sql="delete from wishlist where id_p='"+w.getRefp()+"' ";
        //    ste.executeUpdate(sql);

    }

    @Override
    public void update(wishlist t) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
