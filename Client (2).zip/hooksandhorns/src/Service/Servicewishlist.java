/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;
import Utils.DataBase;
import entite.Client;
import iservicee.iservicew;
import entite.wishlist;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author asus
 */
public class Servicewishlist implements iservicew <wishlist> {
private Connection con;
    private Statement ste;
    public Servicewishlist() {
        con = DataBase.getInstance().getConnection();
        
    }

    
    
    @Override
    public void ajouter(wishlist w) throws SQLException {
        ste = con.createStatement();
//        w.getCl().getEmail();
        String requeteInsert = "INSERT INTO wishlist (id_p,email_c)VALUES ( '" + w.getRefp() + "', '" +w.getEmailc() + "')";
        ste.executeUpdate(requeteInsert);
        
    }

    @Override
    public boolean delete(wishlist w) throws SQLException {
        ste=con.createStatement();
    String sql="delete from wishlist where id_p='"+w.getRefp()+"' ";
        ste.executeUpdate(sql);
        return true;
    }

   

    @Override
    public List<wishlist> readAll(wishlist w) throws SQLException {
        List<wishlist> arr=new ArrayList<>();
    ste=con.createStatement();
    ResultSet rs=ste.executeQuery("SElECT * From  product e inner join  wishlist a on e.idProduct= a.id_p where email_c='"+w.getEmailc()+"' ");
     while (rs.next()) {                
              
               int price=rs.getInt(1);
               String name=rs.getString(2);
               String lastname=rs.getString(3);
               String pw=rs.getString(4);
               String rpw=rs.getString(5);
              
               
               wishlist p=new wishlist (price,name);
     arr.add(p);
     }
    return arr;
    }

  
    
    
}
