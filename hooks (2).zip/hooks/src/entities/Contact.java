/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

/**
 *
 * @author asus
 */
public class Contact {
     
    private int IdContact;
    private int IdClient;
    private String text; 

    public Contact(int id, int IdClient, String text) {
        this.IdContact = id;
        this.IdClient = IdClient;
        this.text = text;
    }

    public Contact(int IdClient, String text) {
        this.IdClient = IdClient;
        this.text = text;
    }
    
    
    public int getIdContact() {
        return IdContact;
    }

    public void setId(int IdContact) {
        this.IdContact = IdContact;
    }

    public int getIdClient() {
        return IdClient;
    }

    public void setIdClient(int IdClient) {
        this.IdClient = IdClient;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
    
    
}
