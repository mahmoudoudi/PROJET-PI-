/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import IService.IService;
import Utils.Database;
import entities.Delivery;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author asus
 */
public class ServiceDelivery implements IService <Delivery>{
    private Connection con;
    private Statement ste;
    private Statement ste1;

    public ServiceDelivery() {
        con = Database.getInstance().getConnection();

    }
public boolean accept(Delivery d) throws SQLException  {

        //  PreparedStatement ste= con.prepareStatement(  " UPDATE `hooks`.`delivery` SET `Destination`= ?,  `CityD`= ?,`CostDelivery`= ?, `EtatD`=? WHERE `IdDelivery`=?");
     PreparedStatement ste=con.prepareStatement( " UPDATE `hooks`.`delivery` SET `EtatD`=1 WHERE `IdDelivery`=?");
        ste.setInt(1, d.getId());
//      ste.setString(3 , d.getDestination());
//   ste.setString(4 , d.getCity()); 
//ste.setFloat(5 , d.getCost());
//          ste.setInt(1, 1);
            ste.executeUpdate();
            return true;
    }
   
    
    public float costbycity (String x) throws SQLException {
        float y=0;
     ste = con.createStatement();
ResultSet rs=ste.executeQuery("SELECT Rate FROM ratecity WHERE City='"+x+"'");
while (rs.next())
        {
          y+=rs.getFloat(2);
         
        }
return y;
    }
        public float getTotal () throws SQLException {
     ste = con.createStatement();
     ste1 = con.createStatement();
ResultSet rs=ste.executeQuery("SELECT IdOrder FROM delivery WHERE IdDelivery=1");
while (rs.next())
        {
         int y=rs.getInt("IdOrder");
         ResultSet rs1=ste1.executeQuery("SELECT TotalO FROM orderp WHERE IdOrder='"+y+"'");
         while (rs1.next())
         {
             float z=rs1.getFloat("TotalO");
         return z;
         }
        }
return 0;
    }


    

//    @Override
//    public boolean update(Delivery t) throws SQLException {
//    boolean test=false;
//
//            PreparedStatement ste= con.prepareStatement(" UPDATE `delivery` SET `d`=?,"
//                    + "`Destination`=?,`CostDelivery`=? WHERE `IdDelivery`=?");
//            ste.setTimestamp(1,t.getDate() );
//              ste.setString(2,t.getDestination() );
//                ste.setFloat(3,  t.getCost() );
//                  
//                    ste.setInt(4,t.getId() );
//                    System.out.println(ste);
//                        ste.executeUpdate();
//            return true;
//    }


   
    public List<Delivery> searchbyid(int id) throws SQLException {
         String requete="SELECT * FROM `hooks`.`delivery`where IdDelivery= '"+id+"'" ;
        ste=con.createStatement() ;
        ResultSet rs=ste.executeQuery(requete);
        List<Delivery> list = new ArrayList<>() ; 
        while(rs.next()){
                int idd=rs.getInt(1);
               int idorder=rs.getInt(2);
               String destination=rs.getString(3);
               String city=rs.getString(4);
               float cost=rs.getFloat(5);
               int etat=rs.getInt(6);
               
              
               
               Delivery p=new Delivery (id,idorder, destination, city, cost,etat);
       
          
        list.add(p) ;
        }
        return list ;
    }
    


    public boolean searchbyname(String firstname) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

 
    public List<Delivery> searchDeliverymanByName(String firstname) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
    }
    public List<String> combo() throws SQLException{
        List<String> arr=new ArrayList<>();
        ste=con.createStatement();
        ResultSet rs= ste.executeQuery("Select City from ratecity");
        while (rs.next()){
            String City=rs.getString(1);
            arr.add(City);
            
        }
        return arr;
    }
       public float coast(String x) throws SQLException{
        
        ste=con.createStatement();
        ResultSet rs= ste.executeQuery("Select Rate from ratecity where City='"+x+"';" );
        while (rs.next()){
            float rate=rs.getFloat(1);
           return rate;
            
        }
        return 0;
    }
       public int deliveryn(String x) throws SQLException{
        
        ste=con.createStatement();
        ResultSet rs= ste.executeQuery("Select count(*) from delivery where CityD='"+x+"';" );
        while (rs.next()){
            int z=rs.getInt(1);
           return z;
            
        }
        return 0;
    }
             public float total() throws SQLException{
        
        ste=con.createStatement();
        ResultSet rs= ste.executeQuery("Select TotalO from orderp where IdOrder='"+1+"';" );
        while (rs.next()){
            float rate=rs.getFloat(1);
           return rate;
            
        }
        return 0;
    }

    @Override
    public void add(Delivery t) throws SQLException {
        //PreparedStatement pre=con.prepareStatement("INSERT INTO hooks.`product` ( IdProduct, NameCategory, NameProduct, DescriptionProduct, QuantityProduct, PriceProduct, Promotion) VALUES ( NULL, ?, ?, ?, ?, ?, ?);");

   PreparedStatement pre=con.prepareStatement("INSERT INTO hooks.`delivery` (`IdDelivery` , `IdOrder` , `Destination` , `CityD` , `CostDelivery` , `EtatD`) VALUES(NULL, ?, ?, ?, ?, ?);");
   pre.setInt(1, 1);
   pre.setString(2 , t.getDestination());
   pre.setString(3 , t.getCity()); 
pre.setFloat(4 , t.getCost());
      pre.setInt(5 ,0);
        pre.executeUpdate();
    }

    @Override
    public void delete(Delivery t) throws SQLException {
        boolean test=false;
    String sql = "DELETE FROM `hooks`.`delivery` WHERE IdDelivery=?";
 
PreparedStatement statement = con.prepareStatement(sql);
statement.setInt(1, t.getId());
 
int rowsDeleted = statement.executeUpdate();
if (rowsDeleted > 0) {
    System.out.println("A delivery was deleted successfully!");
    test=true;
}

    }

    @Override
    public void update(Delivery t) throws SQLException {
        
            
    
    }

    @Override
    public List<Delivery> readAll(Delivery t) throws SQLException {
          List<Delivery> arr=new ArrayList<>();
    ste=con.createStatement();
    ResultSet rs=ste.executeQuery("select * from delivery");
     while (rs.next()) {                
               int IdD=rs.getInt(1);
               int IdO=rs.getInt(2);
               String Des=rs.getString(3);
               String Cit=rs.getString(4);
               float CostD=rs.getFloat(5);
               int Etat=rs.getInt(6);
              
               Delivery p=new Delivery (IdD, IdO, Des, Cit, CostD, Etat);
     arr.add(p);
     }
    return arr;
    }


    public List<Delivery> readAlll() throws SQLException {
          List<Delivery> arr=new ArrayList<>();
    ste=con.createStatement();
    ResultSet rs=ste.executeQuery("select * from delivery");
     while (rs.next()) {                
               int IdD=rs.getInt(1);
               int IdO=rs.getInt(2);
               String Des=rs.getString(3);
               String Cit=rs.getString(4);
               float CostD=rs.getFloat(5);
               int Etat=rs.getInt(6);
               Delivery p=new Delivery (IdD, IdO, Des, Cit, CostD, Etat);
     arr.add(p);
     }
    return arr;
    }
}
