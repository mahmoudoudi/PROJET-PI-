/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;


import java.sql.Timestamp;
import javafx.collections.ObservableList;

/**
 *
 * @author asus
 */
public class Information {
     private int id;
    private String Subject;
    private String Text;
    private Timestamp Date;
    private String Photo;
    public ObservableList<Information> data;

    public Information() {
    }
    
    public Information(int id,String Subject, String Text, Timestamp Date, String Photo) {
        this.id = id;
        this.Subject = Subject;
        this.Text = Text;
        this.Date = Date;
        this.Photo = Photo;
    }

    public Information(String Subject, String Text, Timestamp Date, String Photo) {
        this.Subject = Subject;
        this.Text = Text;
        this.Date = Date;
        this.Photo = Photo;
    }

    public Information(int id) {
        this.id = id;
    }
    
    
    public int getId() {
        return id;
    }

    public String getSubject() {
        return Subject;
    }

    public String getText() {
        return Text;
    }

    public Timestamp getDate() {
        return Date;
    }

    public String getPhoto() {
        return Photo;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setSubject(String Subject) {
        this.Subject = Subject;
    }

    public void setText(String Text) {
        this.Text = Text;
    }

    public void setDate(Timestamp Date) {
        this.Date = Date;
    }

    public void setPhoto(String Photo) {
        this.Photo = Photo;
    }

    @Override
    public String toString() {
        return "Information{" + "id=" + id + ", Subject=" + Subject + ", Text=" + Text + ", Date=" + Date + ", Photo=" + Photo + '}';
    }
    
    
    
}
