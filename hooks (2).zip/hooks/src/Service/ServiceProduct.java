/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import IService.IService;
import Utils.Database;
import entities.Product;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author asus
 */
public class ServiceProduct implements IService<Product> {
     private final Connection con;
    private Statement ste;

    public ServiceProduct() {
        con = Database.getInstance().getConnection();
          

}
      
    
        
    

    public boolean update(String a) throws SQLException {
      
        PreparedStatement pre=con.prepareStatement("UPDATE product SET NameProduct= '" + a + "'  WHERE IdProduct=13 ;");
            pre.executeUpdate();
       
        return true;
    }
    

    
    public int stats1() throws SQLException {
   
    ste=con.createStatement();
  
    ResultSet rs=ste.executeQuery("select count(*) AS total from product WHERE Promotion >0");


      while (rs.next())
      {
          int count=rs.getInt("total");
             return count;
      } 
        return 0;

    }
    public int stats2() throws SQLException {
   
    ste=con.createStatement();
  
    ResultSet rs=ste.executeQuery("select count(*) AS total from product WHERE Promotion =0");


      while (rs.next())
      {
          int count=rs.getInt("total");
             return count;
      } 
        return 0;

    }
    
    public int statsA() throws SQLException {
   
    ste=con.createStatement();
  
    ResultSet rs=ste.executeQuery("select count(*) AS total from product");


      while (rs.next())
      {
          int count=rs.getInt("total");
             return count;
      } 
        return 0;

    }
    public List<String> combo() throws SQLException {
    List<String> arr=new ArrayList<>();
    ste=con.createStatement();
    ResultSet rs=ste.executeQuery("select NameCategory from category");
     while (rs.next()) {                
               String NameCategory=rs.getString(1);
 
              
               arr.add(NameCategory);
     }
    return arr;
    }
    
    
public List<Product> selectitem(int i) throws SQLException {
    List<Product> arr=new ArrayList<>();
    ste=con.createStatement();
    ResultSet rs=ste.executeQuery("select * from productWHERE IdProduct='"+i+"';");
     while (rs.next()) {                
               int IdProduct=rs.getInt(1);
               String NameCategory=rs.getString("NameCategory");
               String NameProduct=rs.getString("NameProduct");
               String DescriptionProduct=rs.getString("DescriptionProduct");
               int QuantityProduct=rs.getInt("QuantityProduct");
               float PriceProduct=rs.getFloat("PriceProduct");
               float Promotion=rs.getFloat("Promotion");
             
               
               
               Product p=new Product (IdProduct, NameCategory, NameProduct, DescriptionProduct, QuantityProduct, PriceProduct, Promotion);
     arr.add(p);
     }
    return arr;
    }
    
    public void ajouter(Product t) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

  
    
    public List<Product> recherche(String aa) throws SQLException{
         List<Product> fish=new ArrayList<>();
         ste=con.createStatement();
        ResultSet rs=ste.executeQuery("Select * from product where NameProduct like '%" + aa + "%' ;");
           while (rs.next()) {                
               int IdProduct=rs.getInt(1);
               String NameCategory=rs.getString("NameCategory");
               String NameProduct=rs.getString("NameProduct");
               String DescriptionProduct=rs.getString("DescriptionProduct");
               int QuantityProduct=rs.getInt("QuantityProduct");
               float PriceProduct=rs.getFloat("PriceProduct");
               float Promotion=rs.getFloat("Promotion");
               
               
               Product p=new Product(NameCategory, NameProduct, DescriptionProduct, QuantityProduct, PriceProduct, Promotion);
     fish.add(p);
     }
        return fish;
    }
    
    public List<Product> promo() throws SQLException{
         List<Product> fish=new ArrayList<>();
         ste=con.createStatement();
        ResultSet rs=ste.executeQuery("Select * from product where Promotion>0.00;");
           while (rs.next()) {                
               int IdProduct=rs.getInt(1);
               String NameCategory=rs.getString("NameCategory");
               String NameProduct=rs.getString("NameProduct");
               String DescriptionProduct=rs.getString("DescriptionProduct");
               int QuantityProduct=rs.getInt("QuantityProduct");
               float PriceProduct=rs.getFloat("PriceProduct");
               float Promotion=rs.getFloat("Promotion");
              
               
               
               Product x=new Product(IdProduct, NameCategory, NameProduct, DescriptionProduct, QuantityProduct, PriceProduct, Promotion);
     fish.add(x);
     }
        return fish;
    }
    
     public List<Product> triL() throws SQLException{
         List<Product> fish=new ArrayList<>();
         ste=con.createStatement();
        ResultSet rs=ste.executeQuery("Select * from product order by PriceProduct;");
           while (rs.next()) {                
               int IdProduct=rs.getInt(1);
               String NameCategory=rs.getString("NameCategory");
               String NameProduct=rs.getString("NameProduct");
               String DescriptionProduct=rs.getString("DescriptionProduct");
               int QuantityProduct=rs.getInt("QuantityProduct");
               float PriceProduct=rs.getFloat("PriceProduct");
               float Promotion=rs.getFloat("Promotion");
              
               
               
               Product x=new Product(IdProduct, NameCategory, NameProduct, DescriptionProduct, QuantityProduct, PriceProduct, Promotion);
     fish.add(x);
     }
        return fish;
    }
     
     
     
    public List<Product> triH() throws SQLException{
         List<Product> fish=new ArrayList<>();
         ste=con.createStatement();
        ResultSet rs=ste.executeQuery("Select * from product order by PriceProduct desc;");
           while (rs.next()) {                
               int IdProduct=rs.getInt(1);
               String NameCategory=rs.getString("NameCategory");
               String NameProduct=rs.getString("NameProduct");
               String DescriptionProduct=rs.getString("DescriptionProduct");
               int QuantityProduct=rs.getInt("QuantityProduct");
               float PriceProduct=rs.getFloat("PriceProduct");
               float Promotion=rs.getFloat("Promotion");
              
               
               
               Product x=new Product(IdProduct, NameCategory, NameProduct, DescriptionProduct, QuantityProduct, PriceProduct, Promotion);
     fish.add(x);
     }
        return fish;
    }

    public void like() {
    }

    @Override
    public void add(Product t) throws SQLException {

    PreparedStatement pre=con.prepareStatement("INSERT INTO `hooks`.`product` ( `IdProduct`, `NameCategory`, `NameProduct`, `DescriptionProduct`, `QuantityProduct`, `PriceProduct`, `Promotion`) VALUES ( NULL, ?, ?, ?, ?, ?, ?);");
    pre.setString(1, t.getNameCategory());
    pre.setString(2, t.getNameProduct());
    pre.setString(3, t.getDescriptionProduct());
    pre.setInt(4, t.getQuantityProduct());
    pre.setFloat(5, t.getPriceProduct());
    pre.setFloat(6, 0);
    pre.executeUpdate();
       
    }

    @Override
    public void delete(Product t) throws SQLException {

          PreparedStatement pre=con.prepareStatement("delete from product WHERE IdProduct='"+t.getIdProduct()+"';");
            pre.executeUpdate();
    }

    @Override
    public void update(Product t) throws SQLException {
            boolean test=false;
            PreparedStatement pre= con.prepareStatement(  "UPDATE product SET NameCategory= ?,  NameProduct= ?, DescriptionProduct= ?, QuantityProduct= ?, PriceProduct= ? ,Promotion= ? WHERE IdProduct='"+t.getIdProduct()+"';");
            pre.setString(1, t.getNameCategory());
    pre.setString(2, t.getNameProduct());
    pre.setString(3, t.getDescriptionProduct());
    pre.setInt(4, t.getQuantityProduct());
    pre.setFloat(5, t.getPriceProduct());
    pre.setFloat(6, t.getPromotion());
    pre.executeUpdate();
        }

    @Override
    public List<Product> readAll(Product t) throws SQLException {
    List<Product> arr=new ArrayList<>();
    ste=con.createStatement();
    ResultSet rs=ste.executeQuery("select * from product");
     while (rs.next()) {                
               int IdProduct=rs.getInt(1);
               String NameCategory=rs.getString("NameCategory");
               String NameProduct=rs.getString("NameProduct");
               String DescriptionProduct=rs.getString("DescriptionProduct");
               int QuantityProduct=rs.getInt("QuantityProduct");
               float PriceProduct=rs.getFloat("PriceProduct");
               float Promotion=rs.getFloat("Promotion");
             
               
               
               Product p=new Product (IdProduct, NameCategory, NameProduct, DescriptionProduct, QuantityProduct, PriceProduct, Promotion);
     arr.add(p);
     }
    return arr;
     }
   

}
