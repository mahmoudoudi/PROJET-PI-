/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import IService.IService;
import Utils.Database;
import entities.Client;
import entities.Evenement;
import entities.ratecity;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import jdk.nashorn.internal.runtime.logging.Logger;

/**
 *
 * @author asus
 */
public class Serviceevenement implements IService<Evenement> {
  private final Connection con;
    private Statement ste;

    public Serviceevenement() {
        con = Database.getInstance().getConnection();

    }

    @Override
    public void add(Evenement e) throws SQLException {
       
        try {
            PreparedStatement pre = con.prepareStatement("INSERT INTO `hooks`.`events` ( `IdEvent`, `NameEvent`, `AddressEvent`, `Type`,`PriceEvent`, `NbrPlace` ,`DescriptionEvent`, `Image`, `dateD` , `dateF`) VALUES ( NULL, ?, ?, ?, ?, ? , ? ,? ,? ,?);");
            pre.setString(1, e.getNameEvent());
            pre.setString(2, e.getAddressEvent());
            pre.setString(3, e.getType());
            pre.setFloat(4, e.getPriceEvent());
            pre.setInt(5, e.getNbrPlace());
            pre.setString(6, e.getDescriptionEvent());
            pre.setString(7, e.getImage());
            pre.setTimestamp(8, e.getDateD());
            pre.setTimestamp(9, e.getDateF());
            pre.executeUpdate();
        } catch (SQLException ex) {
            System.out.println(e);
        }
    }

    @Override
    public void delete(Evenement t) throws SQLException {
        try {
            PreparedStatement pre = con.prepareStatement("DELETE FROM `hooks`.`events` WHERE NameEvent=? ;");
            pre.setString(1, t.getNameEvent());
            if (pre.executeUpdate() != 0) {
                System.out.println("event Deleted");
               
            }
            System.out.println("nom evenement not found!!!");
        } catch (SQLException ex) {
            System.out.println(ex);
        }
     
    }
public void updateEvent(Evenement e) throws SQLException {
      
            PreparedStatement pre = con.prepareStatement("UPDATE events SET AddressEvent=?,PriceEvent=?,NbrPlace=?,IMAGE = ? ,dateD=?,dateF=? WHERE NameEvent=? ");
            pre.setString(1, e.getAddressEvent());
            pre.setFloat(2, e.getPriceEvent());
            pre.setInt(3, e.getNbrPlace());
            pre.setString(4, e.getImage());
            pre.setTimestamp(5, e.getDateD());
            pre.setTimestamp(6, e.getDateF());
            pre.setString(7, e.getNameEvent());

            pre.executeUpdate();
    }
  public boolean updateimage(String NameEvent, String Image) throws SQLException {
        PreparedStatement pre = con.prepareStatement("UPDATE `hooks`.`events` SET IMAGE = ? WHERE NameEvent=? ;");
        pre.setString(1, Image);
        pre.setString(2, NameEvent);
        if (pre.executeUpdate() != 0) {
            System.out.println("event Updated");
            return true;
        }
        System.out.println("nom evenement not found!!!");
        return false;
    }

    public boolean updateprice(String NameEvent, Float PriceEvent) throws SQLException {
        PreparedStatement pre = con.prepareStatement("UPDATE `hooks`.`events` SET PriceEvent = ? WHERE NameEvent=? ;");
        pre.setFloat(1, PriceEvent);
        pre.setString(2, NameEvent);
        if (pre.executeUpdate() != 0) {
            System.out.println("event Updated");
            return true;
        }
        System.out.println("nom evenement not found!!!");
        return false;
    }

    public boolean updateaddress(String NameEvent, String AddressEvent) throws SQLException {
        PreparedStatement pre = con.prepareStatement("UPDATE `hooks`.`events` SET AddressEvent = ? WHERE NameEvent=? ;");
        pre.setString(1, AddressEvent);
        pre.setString(2, NameEvent);
        if (pre.executeUpdate() != 0) {
            System.out.println("event Updated");
            return true;
        }
        System.out.println("nom evenement not found!!!");
        return false;
    }

    public boolean updatenombre(String NameEvent, int NbrPlace) throws SQLException {
        PreparedStatement pre = con.prepareStatement("UPDATE `hooks`.`events` SET NbrPlace = ? WHERE NameEvent=? ;");
        pre.setInt(1, NbrPlace);
        pre.setString(2, NameEvent);
        if (pre.executeUpdate() != 0) {
            System.out.println("event Updated");
            return true;
        }
        System.out.println("nom evenement not found!!!");
        return false;
    }

    public boolean updatedateD(String NameEvent, String DateD) throws SQLException {
        PreparedStatement pre = con.prepareStatement("UPDATE `hooks`.`events` SET DateD = ? WHERE NameEvent=? ;");
        pre.setString(1, DateD);
        pre.setString(2, NameEvent);
        if (pre.executeUpdate() != 0) {
            System.out.println("event Updated");
            return true;
        }
        System.out.println("nom evenement not found!!!");
        return false;
    }

    public boolean updatedateF(String NameEvent, String DateF) throws SQLException {
        PreparedStatement pre = con.prepareStatement("UPDATE `hooks`.`events` SET DateF = ? WHERE NameEvent=? ;");
        pre.setString(1, DateF);
        pre.setString(2, NameEvent);
        if (pre.executeUpdate() != 0) {
            System.out.println("event Updated");
            return true;
        }
        System.out.println("nom evenement not found!!!");
        return false;
    }
    @Override
    public void update(Evenement e) throws SQLException {
        try {
          
            PreparedStatement pre = con.prepareStatement("UPDATE events SET AddressEvent=?,PriceEvent=?,NbrPlace=?,IMAGE = ? ,dateD=?,dateF=? WHERE NameEvent=? ");
            pre.setString(1, e.getAddressEvent());
            pre.setFloat(2, e.getPriceEvent());
            pre.setInt(3, e.getNbrPlace());
            pre.setString(4, e.getImage());
            pre.setTimestamp(5, e.getDateD());
            pre.setTimestamp(6, e.getDateF());
            pre.setString(7, e.getNameEvent());

            pre.executeUpdate();

        } catch (SQLException ex) {
            System.out.println(ex);
        }

    }

    
//    public List<Evenement> readAll(Evenement t) throws SQLException {
//        
//    }

      public List<Evenement> readyByNom(String Nameevent) throws SQLException {
        List<Evenement> arr = new ArrayList<>();
        // ste=con.createStatement();
        // ResultSet rs=ste.executeQuery("select * from evenement");
        PreparedStatement pre = con.prepareStatement("Select * from events  WHERE NameEvent=? " );
        pre.setString(1, Nameevent);
        ResultSet rs = pre.executeQuery();
        while (rs.next()) {
            //int id=rs.getInt(1);
            String NameEvent = rs.getString("NameEvent");
            String AddressEvent = rs.getString("AddressEvent");
            String Type = rs.getString("Type");
            float PriceEvent = rs.getInt("PriceEvent");
            int NbrPlace = rs.getInt("NbrPlace");
            String DescriptionEvent = rs.getString("DescriptionEvent");
            String Image = rs.getString("Image");
            Timestamp dateD = rs.getTimestamp("dateD");
            Timestamp dateF = rs.getTimestamp("dateF");

            Evenement p = new Evenement(NameEvent, AddressEvent, Type, PriceEvent, NbrPlace, DescriptionEvent, Image, dateD, dateF);
            arr.add(p);
        }
        return arr;
    }

    @Override
    public List<Evenement> readAll(Evenement t) throws SQLException {
      List<Evenement> arr = new ArrayList<>();

        try {
            //int id=rs.getInt(1);
            ste = con.createStatement();
            ResultSet rs = ste.executeQuery("select * from events " );
            while (rs.next()) {
                String NameEvent = rs.getString("NameEvent");
                String AddressEvent = rs.getString("AddressEvent");
                String Type = rs.getString("Type");
                float PriceEvent = rs.getInt("PriceEvent");
                int NbrPlace = rs.getInt("NbrPlace");
                String DescriptionEvent = rs.getString("DescriptionEvent");
                String Image = rs.getString("Image");
                Timestamp dateD = rs.getTimestamp("dateD");
                Timestamp dateF = rs.getTimestamp("dateF");

                Evenement p = new Evenement(NameEvent, AddressEvent, Type, PriceEvent, NbrPlace, DescriptionEvent, Image, dateD, dateF);
                arr.add(p);
            }
        } catch (SQLException ex) {
            System.out.println(ex);
        }
        return arr;

    }
      public List<Evenement> readAll1() throws SQLException {
      List<Evenement> arr = new ArrayList<>();

        try {
            //int id=rs.getInt(1);
            ste = con.createStatement();
            ResultSet rs = ste.executeQuery("select * from events " );
            while (rs.next()) {
                String NameEvent = rs.getString("NameEvent");
                String AddressEvent = rs.getString("AddressEvent");
                String Type = rs.getString("Type");
                float PriceEvent = rs.getInt("PriceEvent");
                int NbrPlace = rs.getInt("NbrPlace");
                String DescriptionEvent = rs.getString("DescriptionEvent");
                String Image = rs.getString("Image");
                Timestamp dateD = rs.getTimestamp("dateD");
                Timestamp dateF = rs.getTimestamp("dateF");

                Evenement p = new Evenement(NameEvent, AddressEvent, Type, PriceEvent, NbrPlace, DescriptionEvent, Image, dateD, dateF);
                arr.add(p);
            }
        } catch (SQLException ex) {
            System.out.println(ex);
        }
        return arr;

    }
    }
    

        

