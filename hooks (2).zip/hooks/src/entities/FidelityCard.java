/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

/**
 *
 * @author asus
 */
public class FidelityCard {
     
   private int  IdFidelityCard;
   private int Points;
   private int  IdClient;

    public FidelityCard(int Points, int IdClient) {
        this.Points = Points;
        this.IdClient = IdClient;
    }

    public FidelityCard() {
    }

  
    public FidelityCard(int IdFidelityCard, int Points, int IdClient) {
        this.IdFidelityCard = IdFidelityCard;
        this.Points = Points;
        this.IdClient = IdClient;
    }

    public int getIdFidelityCard() {
        return IdFidelityCard;
    }

    public int getPoints() {
        return Points;
    }

    public int getIdClient() {
        return IdClient;
    }

    public void setIdFidelityCard(int IdFidelityCard) {
        this.IdFidelityCard = IdFidelityCard;
    }

    public void setPoints(int Points) {
        this.Points = Points;
    }

    public void setIdClient(int IdClient) {
        this.IdClient = IdClient;
    }

    @Override
    public String toString() {
        return "FidelityCard{" + "IdFidelityCard=" + IdFidelityCard + ", Points=" + Points + ", IdClient=" + IdClient + '}';
    }
}
