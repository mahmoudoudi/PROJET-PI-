/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

/**
 *
 * @author asus
 */
public class ratecity {
     private String city;
    private float rate;

    public ratecity(String city, float rate) {
        this.city = city;
        this.rate = rate;
    }

    public ratecity(float rate) {
        this.rate = rate;
    }
    

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public float getRate() {
        return rate;
    }

    public void setRate(float rate) {
        this.rate = rate;
    }

    @Override
    public String toString() {
        return "ratecity{" + "city=" + city + ", rate=" + rate + '}';
    }
      
    public float toString1() {
        return rate;
    }
    
    public String toString2() {
        return city;
    }
    
}
