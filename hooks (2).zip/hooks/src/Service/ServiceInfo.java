/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import IService.IService;
import Utils.Database;
import java.sql.Timestamp;
import entities.Information;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author asus
 */
public class ServiceInfo implements IService <Information> {
    
    private Connection con;
    private Statement ste;

    public ServiceInfo() {
        con = Database.getInstance().getConnection();

    }
    

    
    


    public ObservableList<Information> readAll() throws SQLException {
    ObservableList<Information> arr = FXCollections.observableArrayList(); 
    ste=con.createStatement();
    ResultSet rs=ste.executeQuery("select * from news");
     while (rs.next()) {                
               int id=rs.getInt(1);
               String subject=rs.getString("Subject");
               Timestamp date=rs.getTimestamp("Date");
               String text=rs.getString("Text");
               String photo=rs.getString("ImageNews");
               Information p=new Information(id,subject,text,date,photo);
     arr.add(p);
     }
    return arr;
    }
     public boolean searchbyname(String subject) throws SQLException {
        boolean test=false;
    String sql = "SELECT * FROM `hooks`.`news` WHERE Subject=?";
     
     
    PreparedStatement statement = con.prepareStatement(sql);
    statement.setString(1, subject);
    ResultSet r=statement.executeQuery();
    r.last();
    int nbr=r.getRow();
    if(nbr!=0){
        System.out.println("subject found");
        test=true;
        
    }
    else{
        System.out.println("subject not found");
        
    }
        return test;
        
    }
     public ObservableList<Information> searchInformationByName(String subject) throws SQLException {
      String requete="SELECT * FROM `hooks`.`news`where Subject= '"+subject+"'" ;
        ste=con.createStatement() ;
        ResultSet rs=ste.executeQuery(requete);
          ObservableList<Information> list = FXCollections.observableArrayList(); 
            //ObservableList<Information> data = new ObservableList<>();
        while(rs.next()){
        Information d;
            d = new Information(rs.getString(2),rs.getString(3),rs.getTimestamp(4),rs.getString(5));
        list.add(d) ;
        }
        return list ;
    }

    @Override
    public void add(Information t) throws SQLException {
        ste = con.createStatement();
        String requeteInsert = "INSERT INTO news (IdNews,Subject,Text,Date,ImageNews) VALUES (NULL, '" + t.getSubject() + "', '" + t.getText() + "', '" + t.getDate() + "', '" + t.getPhoto() + "');";
        ste.executeUpdate(requeteInsert);
    }

    @Override
    public void delete(Information t) throws SQLException {
          boolean test=false;
    String sql = "DELETE FROM `hooks`.`news` WHERE Subject='"+t.getSubject()+"'";
    PreparedStatement statement = con.prepareStatement(sql);
    int rowsDeleted = statement.executeUpdate();
    if (rowsDeleted > 0) {
    System.out.println("News was deleted successfully!");
    test=true;
    }
    }

    @Override
    public void update(Information t) throws SQLException {
      boolean test=false;

            PreparedStatement ste= con.prepareStatement(" UPDATE `hooks`.`news` SET `Subject`= ?,`Text`= ?, `Date`= ?,`ImageNews`= ? WHERE `Subject`=?");
            ste.setString(1,t.getSubject() );
              ste.setString(2,t.getText() );
                ste.setTimestamp(3,  t.getDate() );
                  ste.setString(4, t.getPhoto() );
                    //ste.setInt(5,t.getId() );
                    ste.setString(5,t.getSubject() );
                    System.out.println(ste);
                        ste.executeUpdate();
            
    }
    @Override
    public List<Information> readAll(Information t) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
