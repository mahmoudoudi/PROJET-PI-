/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import Service.ServiceDeliveryMan;

/**
 *
 * @author asus
 */
public class DeliveryMan {
   private int id;
    private String firstname;
    private String lastname;
    private String address;
    private String email;
    private int phonenumber;
    private String available;
    private float score;
    private float numberscore;
    private String PasswordD;

   
    

    public DeliveryMan(String PasswordD) {
        this.PasswordD = PasswordD;
    }
   
    

 public DeliveryMan(String firstname,String lastname,String address,String email,int phonenumber,String PasswordD){
     this.firstname=firstname;
     this.lastname=lastname;
     this.address=address;
     this.email=email;
     this.phonenumber=phonenumber;
     this.PasswordD=PasswordD;
     
 }

 
    public DeliveryMan(int id, String firstname, String lastname, String address, String email, int phonenumber, String available, float score, float numberscore) {
        this.id = id;
        this.firstname = firstname;
        this.lastname = lastname;
        this.address = address;
        this.email = email;
        this.phonenumber = phonenumber;
        this.available = available;
        this.score =score;
        this.numberscore=numberscore ;
    }

    public DeliveryMan(int id, String firstname, String lastname, String address, String email, int phonenumber, String available, float score, float numberscore, String PasswordD) {
        this.id = id;
        this.firstname = firstname;
        this.lastname = lastname;
        this.address = address;
        this.email = email;
        this.phonenumber = phonenumber;
        this.available = available;
        this.score = score;
        this.numberscore = numberscore;
        this.PasswordD = PasswordD;
    }

    public DeliveryMan(int id, String firstname, String lastname, String address, String email, int phonenumber) {
        this.id = id;
        this.firstname = firstname;
        this.lastname = lastname;
        this.address = address;
        this.email = email;
        this.phonenumber = phonenumber;
    }
    
    

    public DeliveryMan(int id, String firstname, String lastname, String address, String email, int phonenumber, String available) {
        this.id = id;
        this.firstname = firstname;
        this.lastname = lastname;
        this.address = address;
        this.email = email;
        this.phonenumber = phonenumber;
        this.available = available;
    }

    public DeliveryMan(String firstname, String lastname, String address, String email, int phonenumber, String available, float score, float numberscore) {
        this.firstname = firstname;
        this.lastname = lastname;
        this.address = address;
        this.email = email;
        this.phonenumber = phonenumber;
        this.available = available;
        this.score = score;
        this.numberscore = numberscore;
    }
 

    public DeliveryMan(String firstname, String lastname, String address, String email, int phonenumber) {
        this.firstname = firstname;
        this.lastname = lastname;
        this.address = address;
        this.email = email;
        this.phonenumber = phonenumber;
    }
    

    public DeliveryMan(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(int phonenumber) {
        this.phonenumber = phonenumber;
    }

    public String getAvailable() {
        return available;
    }

  public String getAvailableI() {
        return "Yes";
    }


    public void setAvailable(String available) {
        this.available = available;
    }

    public float getScore() {
        return score;
    }

    public void setScore(float score) {
        this.score = score;
    }

    public float getNumberscore() {
        return numberscore;
    }

    public void setNumberscore(float numberscore) {
        this.numberscore = numberscore;
    }

    public String getPasswordD() {
        return PasswordD;
    }

    public void setPasswordD(String PasswordD) {
        this.PasswordD = PasswordD;
    }
    
    

    @Override
    public String toString() {
        return "DeliveryMan{" + "id=" + id + ", firstname=" + firstname + ", lastname=" + lastname + ", address=" + address + ", email=" + email + ", phonenumber=" + phonenumber + ", available=" + available + '}';
    }
  
    public int toStringID() {
            return id;
    }
      public String toStringName() {
            return firstname;
    }
        public String toStringLastName() {
            return lastname;
    }
          public String toStringAddress() {
            return address;
    }
            public String toStringEmail() {
            return email;
    }
              public int toStringPhoneNumber() {
            return phonenumber;
    }
              
 public String toStringP() {
            return PasswordD;
    } 
}
