/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import IService.IService;
import Utils.Database;
import entities.Client;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author asus
 */
public class ServiceClient implements IService<Client>{
      private final Connection con;
    private Statement ste;

    public ServiceClient() {
        con = Database.getInstance().getConnection();

    }

    /**
     *
     *
     * pre.executeUpdate();
     *
     * @param t
     * @throws SQLException
     */
   

  

   
public boolean session (int a) throws SQLException {
        ste=con.createStatement();
        ResultSet rs=ste.executeQuery("Select count(*) AS total from client where IdClient='"+a+"' ");
        while (rs.next()){
            int count=rs.getInt("total");
            if (count>0)
            {
            
                return true ;
                
            }
            
        }
         return false ;   
    }
    
   

  
    public boolean checkmail(String e) {

        try {
            ste = con.createStatement();
            ResultSet rs = ste.executeQuery("SELECT * FROM Client Where EmailClient = '" + e + "' ");

            if (rs.next()) {
                return true;
            }
        } catch (SQLException ex) {
            System.out.println(ex);
        }

        return false;

    }

    @Override
    public void add(Client t) throws SQLException {
        ste = con.createStatement();

        String requeteInsert = "INSERT INTO client ( IdClient, EmailClient, Name,"
                + "LastName, Password ,Adress) "
                + "VALUES "
                + "(NULL, '" + t.getEmailClient() + "', '" + t.getName() + "', '" + t.getLastName() + " ', '" + t.getPassword() + "'"
                + ", '" + t.getAdress() + " ');";
        ste.executeUpdate(requeteInsert);
    }

    @Override
    public void delete(Client t) throws SQLException {
        ste = con.createStatement();
        String sql = "delete from client where EmailClient='"+t.getEmailClient()+ "' ";
        ste.executeUpdate(sql);
        
    }

    @Override
    public void update(Client t) throws SQLException {
      ste = con.createStatement();
        String sql = "update client Set  Name= '" 
                + t.getName() + "',LastName='" + t.getLastName() + "',Adress='" + t.getAdress() + "' where EmailClient='"+t.getEmailClient()+ "'  ";
        ste.executeUpdate(sql);
        
    }

    @Override
    public List<Client> readAll(Client t) throws SQLException {
        List<Client> arr = new ArrayList<>();
        ste = con.createStatement();
        ResultSet rs = ste.executeQuery("select * from client");
        while (rs.next()) {

            String email = rs.getString(1);
            String name = rs.getString(2);
            String lastname = rs.getString(3);
            String pw = rs.getString(4);
            String rpw = rs.getString(5);

            Client p = new Client(email, name, lastname, pw, rpw);
            arr.add(p);
        }
        return arr;
    }
}
