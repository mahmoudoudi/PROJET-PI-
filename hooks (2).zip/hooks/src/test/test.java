/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import Service.ServiceClient;
import Service.ServiceDelivery;
import Service.ServiceDeliveryMan;
import entities.Client;
import entities.Contact;
import entities.Delivery;
import entities.DeliveryMan;
import entities.Information;

/**
 *
 * @author asus
 */
public class test {
    ServiceClient serC = new ServiceClient();
    ServiceDelivery serD = new ServiceDelivery();
    ServiceDeliveryMan serDM = new ServiceDeliveryMan();
    Client c= new Client(2,"aagg","aa","aaa","aaa","aaaa");
    Delivery d= new Delivery("aaa","aaaa", (float) 32.5);
    DeliveryMan dm = new DeliveryMan("aa","aaa","aaa","aaa",596);
    java.sql.Timestamp timestamp = java.sql.Timestamp.valueOf("2020-09-23 10:10:10.0");
    Information i= new Information("miboun","aaaa",timestamp,"tahan");
    
    
    
}
