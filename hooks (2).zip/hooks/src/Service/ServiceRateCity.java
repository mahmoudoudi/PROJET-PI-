/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import IService.IService;
import Utils.Database;
import com.mysql.jdbc.Statement;
import entities.ratecity;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author asus
 */
public class ServiceRateCity implements IService<ratecity>{
   private Connection con;
    private Statement ste;

    public ServiceRateCity() {
        con = Database.getInstance().getConnection();

    }


    
    public boolean updateN( float r,String c) throws SQLException {
      
        PreparedStatement pre=con.prepareStatement("UPDATE ratecity SET Rate= '" +r+ "'  WHERE City= '"+c+"';");
            pre.executeUpdate();
       
        return true;
    }

    
    public boolean UpdateRate(ratecity t) throws SQLException {
        boolean test=false;

            PreparedStatement ste= con.prepareStatement(" UPDATE ratecity SET Rate`=? WHERECity`=?");
            ste.setFloat(1,t.getRate() );
              ste.setString(2,t.getCity() );
               
                    System.out.println(ste);
                        ste.executeUpdate();
            return true;
    }

    
    public List<ratecity> SearchRateByCity(String city) throws SQLException {
        String requete="SELECT rate FROM hooks.`ratecity`where City= '"+city+"'" ;
        ste = (Statement) con.createStatement();
        ResultSet rs=ste.executeQuery(requete);
        List<ratecity> list = new ArrayList<>() ; 
        while(rs.next()){
        ratecity r;
            r = new ratecity(rs.getFloat(1));
        list.add(r) ;
        }
        return list ;
    }

    
    public List<ratecity> readAll() throws SQLException {
           List<ratecity> arr=new ArrayList<>();
    ste=   (Statement) con.createStatement();
    ResultSet rs=ste.executeQuery("select * from ratecity");
     while (rs.next()) {                
               String City=rs.getString(1);
               float rate=rs.getFloat(2);
               
              
               
               ratecity p=new ratecity (City, rate);
     arr.add(p);
     }
    return arr;
    }
   
      public List<ratecity> triL() throws SQLException{
         List<ratecity> fish=new ArrayList<>();
         ste=(Statement) con.createStatement();
        ResultSet rs=ste.executeQuery("Select * from ratecity order by Rate;");
           while (rs.next()) {                
               
               String city=rs.getString("City");
               float rate=rs.getFloat("Rate");
               
              
               
               
               ratecity x=new ratecity(city,rate);
     fish.add(x);
     }
        return fish;
    }
     
     
     
    

    @Override
    public void add(ratecity t) throws SQLException {
       ste = (Statement) con.createStatement();
        String requeteInsert = "INSERT INTO hooks.`ratecity` (City, Rate)"
                + "VALUES "
                + "( '" + t.getCity() + "', '" + t.getRate()  + " ');";
        ste.executeUpdate(requeteInsert);
    }

    @Override
    public void delete(ratecity t) throws SQLException {
         boolean test=false;
    String sql = "DELETE FROM hooks.`ratecity` WHERE City=?";
 
PreparedStatement statement = con.prepareStatement(sql);
statement.setString(1, t.getCity());
int rowsDeleted = statement.executeUpdate();
if (rowsDeleted > 0) {
    System.out.println("A ratecity was deleted successfully!");
    test=true;
}
    }

    @Override
    public void update(ratecity t) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<ratecity> readAll(ratecity t) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
}
