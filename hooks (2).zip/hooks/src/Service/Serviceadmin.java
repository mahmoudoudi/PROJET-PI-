/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import Utils.Database;
import entities.admin;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author asus
 */
public class Serviceadmin {
     private Connection con;
    private Statement ste;

    public Serviceadmin() {
        con = Database.getInstance().getConnection();

    }
    public boolean login (admin a) throws SQLException {
        ste=con.createStatement();
        ResultSet rs=ste.executeQuery("Select count(*) AS total from admin where username= '"+a.getUsername()+"' and password='" +a.getPassword()+"'");
        while (rs.next()){
            int count=rs.getInt("total");
            if (count>0)
            {
                return true;
            }
            
        }
            return false;   
    }
   
}
