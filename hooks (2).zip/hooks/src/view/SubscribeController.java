/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import Service.Serviceadmin;
import Utils.Database;

import entities.admin;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author asus
 */
public class SubscribeController implements Initializable {
    @FXML
    private TextField txtUsername;
    @FXML
    private Label lblErrors;

    @FXML
    private TextField txtPassword;

    @FXML
    private Button btnSignin;
    
    @FXML
    private AnchorPane an;
   
     

    /**
     * Initializes the controller class.
     */
     /*final Connection con;
    private Statement ste;
    public SubscribeController() {
        con = Database.getInstance().getConnection();
    }*/

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
       /*  if (con == null) {
            lblErrors.setTextFill(Color.TOMATO);
            lblErrors.setText("Server Error : Check");
        } else {
            lblErrors.setTextFill(Color.BLUE);
            lblErrors.setText("Server is up : Good to go");
        }*/
    }    

    @FXML
    private void handleButtonAction(ActionEvent event) throws SQLException, IOException {
        
        //login here String status = "Success";
        Serviceadmin serA=new Serviceadmin();
        String username = txtUsername.getText();
        
        String password = txtPassword.getText();
        admin a=new admin(username,password);
        if (username.isEmpty() || password.isEmpty()) {
            setLblError(Color.TOMATO, "Empty credentials");
            String status = "Error";
            System.out.println("enter your data!");
        } else {
            boolean userc;
            boolean passc;
            userc=serA.login(a);
          
            if ((userc==true))
            {  
          
             FXMLLoader loader = new FXMLLoader
                        (getClass()
                         .getResource("dashboard.fxml"));
            try {
                Parent root = loader.load();
             
                btnSignin.getScene().setRoot(root);
                
           } catch (IOException ex) {
                System.out.println(ex);
                }
            // DashboardController apc = loader.getController();
          //  String s;
            
            /*int t= resultSet.getInt("IdClient");
                System.out.println(t);
            s=  resultSet.getString("Name");
               resultSet.getString("LastName");*/
             
                  //apc.getidclient(t);
               // apc.setResNom(s);
              //  apc.setResPrenom(tfPrenom);
               
       
            }
            else if ((userc==false)){
                 setLblError(Color.TOMATO, "Enter Correct Email/Password");
                 String status = "Error";
                 System.out.println("correct your data ");
            }
//            //query
//            String sql = "SELECT * FROM Client Where EmailClient = ? and Password = ?";
//            try {
//                PreparedStatement preparedStatement = con.prepareStatement(sql);
//                preparedStatement.setString(1, email);
//                preparedStatement.setString(2, password);
//              
//                ResultSet resultSet = preparedStatement.executeQuery();
//                if (!resultSet.next()) {
//                    setLblError(Color.TOMATO, "Enter Correct Email/Password");
//                    String status = "Error";
//                    System.out.println("correct your data ");
//                } else {
//                    setLblError(Color.BLUE, "Login Successful..Redirecting..");
//                    System.out.println("mriglin");
//                     FXMLLoader loader = new FXMLLoader
//                        (getClass()
//                         .getResource("dashboard.fxml"));
//            try {
//                
//                Parent root = loader.load();
//             DashboardController apc = loader.getController();
//            String s;
//            int t= resultSet.getInt("IdClient");
//                System.out.println(t);
//            s=  resultSet.getString("Name");
//               resultSet.getString("LastName");
//             
//                  apc.getidclient(t);
//               // apc.setResNom(s);
//              //  apc.setResPrenom(tfPrenom);
//                btnSignin.getScene().setRoot(root);
//                
//           } catch (IOException ex) {
//                System.out.println(ex);
//                }
//                    
//                }
//            } catch (SQLException ex) {
//                System.err.println(ex.getMessage());
//                //status = "Exception";
//            }
        }
    }


   
    
    private void setLblError(Color color, String text) {
        lblErrors.setTextFill(color);
        lblErrors.setText(text);
        System.out.println(text);
       
    }

   

    
    
}
