/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

/**
 *
 * @author MED
 */
public class Orderp {
    private int IdOrder ;
    //private Cart IdCart ;
    private int IdClient ;
    private String EmailClient ;
    private String  PaymentMethod ;
    private int PhoneNumber ;
    private float TotalO ;

    public Orderp() {
    }

    public Orderp(int IdOrder, int IdClient, String EmailClient, int PhoneNumber, String PaymentMethod, float TotalO) {
        this.IdOrder = IdOrder;
        this.IdClient = IdClient;
        this.EmailClient = EmailClient;
        this.PaymentMethod = PaymentMethod;
        this.PhoneNumber = PhoneNumber;
        this.TotalO = TotalO;
    }

    public Orderp(int IdClient, String EmailClient, String PaymentMethod, int PhoneNumber, float TotalO) {
        this.IdClient = IdClient;
        this.EmailClient = EmailClient;
        this.PaymentMethod = PaymentMethod;
        this.PhoneNumber = PhoneNumber;
        this.TotalO = TotalO;
    }

    public Orderp(int IdClient, String EmailClient,int PhoneNumber , String PaymentMethod,float TotalO ) {
        this.IdClient = IdClient;
        this.EmailClient = EmailClient;
        this.PaymentMethod = PaymentMethod;
        this.PhoneNumber = PhoneNumber;
          this.TotalO = TotalO;
    }

//    public Orderp(int IdClient, String EmailClient, int PhoneNumber, float TotalO) {
//        this.IdClient = IdClient;
//        this.EmailClient = EmailClient;
//        this.PhoneNumber = PhoneNumber;
//        this.TotalO = TotalO;
//    }
//
//    public Orderp(Cart IdCart, int IdClient, String EmailClient, int PhoneNumber, float TotalO) {
//       // this.IdCart = IdCart;
//        this.IdClient = IdClient;
//        this.EmailClient = EmailClient;
//        this.PhoneNumber = PhoneNumber;
//        this.TotalO = TotalO;
//    }
//
//    public Orderp(int IdOrder, Cart IdCart, int IdClient, String EmailClient, String PaymentMethod, int PhoneNumber, float TotalO) {
//        this.IdOrder = IdOrder;
//       // this.IdCart = IdCart;
//        this.IdClient = IdClient;
//        this.EmailClient = EmailClient;
//        this.PaymentMethod = PaymentMethod;
//        this.PhoneNumber = PhoneNumber;
//        this.TotalO = TotalO;
//    }
//
//    public Orderp(int IdClient, String EmailClient, int PhoneNumber, String PaymentMethod) {
//        this.IdClient = IdClient;
//        this.EmailClient = EmailClient;
//        this.PaymentMethod = PaymentMethod;
//        this.PhoneNumber = PhoneNumber;
//    }
//
//    public Orderp(int IdClient, String EmailClient, String PaymentMethod, int PhoneNumber, float TotalO) {
//        this.IdClient = IdClient;
//        this.EmailClient = EmailClient;
//        this.PaymentMethod = PaymentMethod;
//        this.PhoneNumber = PhoneNumber;
//        this.TotalO = TotalO;
//    }

    public int getIdOrder() {
        return IdOrder;
    }

    public void setIdOrder(int IdOrder) {
        this.IdOrder = IdOrder;
    }

//    public Cart getIdCart() {
//        return IdCart;
//    }

    public String getPaymentMethod() {
        return PaymentMethod;
    }

    public void setPaymentMethod(String PaymentMethod) {
        this.PaymentMethod = PaymentMethod;
    }

//    public void setIdCart(Cart IdCart) {
//        this.IdCart = IdCart;
//    }

    public int getIdClient() {
        return IdClient;
    }

    public void setIdClient(int IdClient) {
        this.IdClient = IdClient;
    }

    public String getEmailClient() {
        return EmailClient;
    }

    public void setEmailClient(String EmailClient) {
        this.EmailClient = EmailClient;
    }

    public int getPhoneNumber() {
        return PhoneNumber;
    }

    public void setPhoneNumber(int PhoneNumber) {
        this.PhoneNumber = PhoneNumber;
    }

    public float getTotalO() {
        return TotalO;
    }

    public void setTotalO(float TotalO) {
        this.TotalO = TotalO;
    }
    
}
