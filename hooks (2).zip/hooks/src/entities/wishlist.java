/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

/**
 *
 * @author asus
 */
public class wishlist {
       private int IdClient;
    private String IdProduct;

    public wishlist(int IdClient, String IdProduct) {
        this.IdClient = IdClient;
        this.IdProduct = IdProduct;
    }

    public int getIdClient() {
        return IdClient;
    }

    public String getIdProduct() {
        return IdProduct;
    }

    public void setIdClient(int IdClient) {
        this.IdClient = IdClient;
    }

    public void setIdProduct(String IdProduct) {
        this.IdProduct = IdProduct;
    }

    @Override
    public String toString() {
        return "wishlist{" + "IdClient=" + IdClient + ", IdProduct=" + IdProduct + '}';
    }

}
