/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import Service.ServiceClient;
import Service.Serviceadmin;
import Utils.Database;
import entities.Client;
import entities.admin;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;

/**
 * FXML Controller class
 *
 * @author asus
 */
public class SigninfrontController implements Initializable {

    @FXML
    private TextField txtUsername;
    @FXML
    private Label lblErrors;

    @FXML
    private TextField txtPassword;

    @FXML
    private Button btnSignin;

    @FXML
    private AnchorPane an;
    @FXML
    private Hyperlink labelemail3;
    @FXML
    private Label labelemail;
    @FXML
    private Button signupbtn;
final Connection con;
    private Statement ste;
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
 
        
    } // TODO}
    // TODO

    public SigninfrontController() { 
        con = Database.getInstance().getConnection();
    }
   
    @FXML
    void handleButtonAction(ActionEvent event) throws SQLException, IOException {

        //login here String status = "Success";
        ServiceClient serA = new ServiceClient();
        String username = txtUsername.getText();

        String password = txtPassword.getText();
        Client a = new Client(username, password);
        if (username.isEmpty() || password.isEmpty()) {
            setLblError(Color.TOMATO, "Empty credentials");
            String status = "Error";
            System.out.println("enter your data!");
        } else {
            //query
            String sql = "SELECT * FROM Client Where Name = ? and Password = ?";
            try {
                PreparedStatement preparedStatement = con.prepareStatement(sql);
                preparedStatement.setString(1, username);
                preparedStatement.setString(2, password);

                ResultSet resultSet = preparedStatement.executeQuery();
                if (!resultSet.next()) {
                    setLblError(Color.TOMATO, "Enter Correct Email/Password");
                    String status = "Error";
                    System.out.println("correct your data ");
                } else {
                    setLblError(Color.BLUE, "Login Successful..Redirecting..");
                    System.out.println("mriglin");
                    FXMLLoader loader = new FXMLLoader(getClass()
                            .getResource("front.fxml"));
                    try {

                        Parent root = loader.load();
                        FrontController apc = loader.getController();
                        String s;
                        int t = resultSet.getInt("IdClient");
                        System.out.println(t);
                        s = resultSet.getString("Name");

                        apc.getidclient(t);
               apc.getname(username);
                        //  apc.setResPrenom(tfPrenom);
                        btnSignin.getScene().setRoot(root);

                    } catch (IOException ex) {
                        System.out.println(ex);
                    }

                }
            } catch (SQLException ex) {
                System.err.println(ex.getMessage());
                //status = "Exception";
            }

        }
    }

    private void setLblError(Color color, String text) {
        lblErrors.setTextFill(color);
        lblErrors.setText(text);
        System.out.println(text);

    }

    @FXML
    private void signupaction() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass()
                .getResource("signup.fxml"));

        Parent root = loader.load();

        signupbtn.getScene().setRoot(root);
        System.out.println("fbn,n");
    }

    @FXML
    private void mailaction() {
        Mail n = new Mail();
        String password = txtPassword.getText();
        n.envoyerclient(password);
        labelemail.setTextFill(Color.BLUE);
        labelemail.setText("Mail Sent");
    }
}
