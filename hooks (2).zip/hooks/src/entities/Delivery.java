/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

/**
 *
 * @author asus
 */
public class Delivery {
      private int id;
     private int idorder;
    private String destination;
    private float cost;
    private String City;
    private int etat;

    public Delivery() {
    }
    


    public Delivery(int id, String destination, float cost, String City) {
        this.id = id;
        this.destination = destination;
        this.cost = cost;
        this.City = City;
    }
        
        
    public Delivery(int id,int idorder, String destination,String City,float cost,int etat) {
        this.id = id;
        this.idorder=idorder;
        this.destination = destination;
        this.City=City;
        this.cost = cost;
        this.etat=etat;
        
    }



    public Delivery(String destination,  String City,float cost) {
        this.destination = destination;
        this.cost = cost;
        this.City = City;
    }

    public Delivery(int id, String destination, float cost, String City, int etat) {
        this.id = id;
        this.destination = destination;
        this.cost = cost;
        this.City = City;
        this.etat = etat;
    }
  

 

    public Delivery(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

   

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public float getCost() {
        return cost;
    }

    public void setCost(float cost) {
        this.cost = cost;
    }

    public int getIdorder() {
        return idorder;
    }

    public void setIdorder(int idorder) {
        this.idorder = idorder;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String City) {
        this.City = City;
    }

   
    public int toString1() {
        return id;
    }
}
