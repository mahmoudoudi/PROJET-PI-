/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entite;

/**
 *
 * @author asus
 */
public class wishlist {
    private int refp;
    private String email;

    public Client getCl() {
        return cl;
    }

    public void setCl(Client cl) {
        this.cl = cl;
    }
    private String emailc;
private Client cl;
    public wishlist(int refp, String email) {
        this.refp = refp;
        this.email = email;
    }

    public int getRefp() {
        return refp;
    }

    public String getEmailc() {
        return emailc;
    }

    public void setRefp(int refp) {
        this.refp = refp;
    }

    public void setEmailc(String emailc) {
        this.emailc = emailc;
    }

    @Override
    public String toString() {
        return "wishlist{" + "refp=" + refp + ", emailc=" + emailc + '}';
    }
    
    
}
