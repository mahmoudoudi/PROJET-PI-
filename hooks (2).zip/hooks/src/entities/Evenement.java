/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.sql.Timestamp;

/**
 *
 * @author asus
 */
public class Evenement {
     int IdEvent ;
    String NameEvent;
    String AddressEvent;
    String Type;
    float PriceEvent;
    int NbrPlace;
    String DescriptionEvent;
    String Image;
    Timestamp DateD;
    Timestamp DateF;   

    public Evenement(String NameEvent, String AddressEvent, String Type, float PriceEvent, int NbrPlace, String DescriptionEvent, String Image, Timestamp DateD, Timestamp DateF) {
        this.NameEvent = NameEvent;
        this.AddressEvent = AddressEvent;
        this.Type = Type;
        this.PriceEvent = PriceEvent;
        this.NbrPlace = NbrPlace;
        this.DescriptionEvent = DescriptionEvent;
        this.Image = Image;
        this.DateD = DateD;
        this.DateF = DateF;
    }

    public String getNameEvent() {
        return NameEvent;
    }

    public String getAddressEvent() {
        return AddressEvent;
    }

    public String getType() {
        return Type;
    }

    @Override
    public String toString() {
        return "Evenement{" + "NameEvent=" + NameEvent + ", AddressEvent=" + AddressEvent + ", Type=" + Type + ", PriceEvent=" + PriceEvent + ", NbrPlace=" + NbrPlace + ", DescriptionEvent=" + DescriptionEvent + ", Image=" + Image + ", DateD=" + DateD + ", DateF=" + DateF + '}';
    }

    public float getPriceEvent() {
        return PriceEvent;
    }

    public int getNbrPlace() {
        return NbrPlace;
    }

    public String getDescriptionEvent() {
        return DescriptionEvent;
    }

    public String getImage() {
        return Image;
    }

    public Timestamp getDateD() {
        return DateD;
    }

    public Timestamp getDateF() {
        return DateF;
    }

    public void setNameEvent(String NameEvent) {
        this.NameEvent = NameEvent;
    }

    public void setAddressEvent(String AddressEvent) {
        this.AddressEvent = AddressEvent;
    }

    public void setType(String Type) {
        this.Type = Type;
    }

    public void setPriceEvent(float PriceEvent) {
        this.PriceEvent = PriceEvent;
    }

    public void setNbrplace(int NbrPlace) {
        this.NbrPlace = NbrPlace;
    }

    public void setDescriptionEvent(String DescriptionEvent) {
        this.DescriptionEvent = DescriptionEvent;
    }

    public void setImage(String Image) {
        this.Image = Image;
    }

    public void setDateD(Timestamp DateD) {
        this.DateD = DateD;
    }

    public void setDateF(Timestamp DateF) {
        this.DateF = DateF;
    }
    
    public int toStringId() {
       return IdEvent ;
    }
    
    public String toStringName() {
    return NameEvent;

    }
    public String toStringAddressEvent() {
    return AddressEvent; 
    }
     public String toStringType() {
    return Type;
    }
      public float toStringPriceEvent() {
    return PriceEvent;
    }
        public int toStringNbrPlace() {
    return NbrPlace;
    }
          public String toStringDescriptionEvent() {
    return DescriptionEvent; 
    }
               public String toStringImage() {
    return Image; 
    }
   public Timestamp toStringDateD() {
    return DateD;
    }
    public Timestamp toStringDateF() {
    return DateF;  
    }
}
