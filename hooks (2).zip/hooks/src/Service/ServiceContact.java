/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import IService.IService;
import Utils.Database;
import entities.Contact;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

/**
 *
 * @author asus
 */
public class ServiceContact implements IService <Contact>{
     
    private Connection con;
    private Statement ste;

    public ServiceContact() {
        con = Database.getInstance().getConnection();

    }
   
    
    


    @Override
    public void add(Contact t) throws SQLException {
         ste = con.createStatement();
        String requeteInsert = "INSERT INTO contact (IdContact,IdClient,TextContact) VALUES (NULL,'" + t.getIdClient() + "', '" + t.getText() + "');";
        ste.executeUpdate(requeteInsert);
    }

    @Override
    public void delete(Contact t) throws SQLException {
        boolean test=false;
    String sql = "DELETE FROM `hooks`.`Contact` WHERE IdClient=?";
 
    PreparedStatement statement = con.prepareStatement(sql);
    statement.setInt(1, t.getIdClient());
    int rowsDeleted = statement.executeUpdate();
    if (rowsDeleted > 0) {
    System.out.println("News was deleted successfully!");
    test=true;
}

    }

    @Override
    public void update(Contact t) throws SQLException {
          boolean test=false;

            PreparedStatement ste= con.prepareStatement(  " UPDATE `hooks`.`Contact` SET `text`= ? WHERE `IdClient`=?");
            ste.setString(1,t.getText() );
                    ste.setInt(2,t.getIdClient());
                    System.out.println(ste);
                        ste.executeUpdate();
           
    }

    @Override
    public List<Contact> readAll(Contact t) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

  
    
}
