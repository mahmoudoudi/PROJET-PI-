/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import IService.IService;
import Utils.Database;
import entities.Category;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author asus
 */
public class ServiceCategory implements IService <Category>{
    
    private final Connection con;
    private Statement ste;
   private Statement ste1;

    public ServiceCategory() {
        con = Database.getInstance().getConnection();

}
     
     
 
public boolean promotionCat(String a, float p) throws SQLException {
      
        PreparedStatement pre=con.prepareStatement("UPDATE product SET Promotion= '" + p + "'  WHERE NameCategory='"+a+"';");
            pre.executeUpdate();
       
        return true;
    }
    public boolean updateN(String a, int i) throws SQLException {
      
        PreparedStatement pre=con.prepareStatement("UPDATE category SET NameCategory= '" + a + "'  WHERE IdCategory='"+i+"';");
            pre.executeUpdate();
       
        return true;
    }
     
//       public boolean update1(int i) throws SQLException {
//      
//        PreparedStatement pre=con.prepareStatement("UPDATE category SET DescriptionCategory= '" + a + "'  WHERE IdCategory='"+i+"';");
//            pre.executeUpdate();
//       
//        return true;
//    }

public int readQS() throws SQLException {
    List<Category> arr=new ArrayList<>();
    ste=con.createStatement();
    ResultSet rs=ste.executeQuery("SELECT  count(category.IdCategory) as total FROM category \n" +
"            INNER JOIN product ON product.NameCategory=category.NameCategory \n" +
"            GROUP by category.NameCategory ORDER By total DESC");
     while (rs.next()) {  

         
               int y=rs.getInt("total");
             return y;
     }
    return 0;
    }
public List<Category> readQQ() throws SQLException {
    List<Category> arr=new ArrayList<>();
    ste=con.createStatement();
    ResultSet rs=ste.executeQuery("SELECT  category.NameCategory sum(product.QuantityProduct) as total FROM category \n" +
"            INNER JOIN product ON product.NameCategory=category.NameCategory \n" +
"            GROUP by category.NameCategory ORDER By total DESC");
     while (rs.next()) {  

         
               String name=rs.getString("category.NameCategory");
               int total=rs.getInt("total");
               Category c1=new Category(name,total);
             arr.add(c1);
     }
    return arr;
    }
public List<Category> readQ() throws SQLException {
    List<Category> arr=new ArrayList<>();
    ste=con.createStatement();
    ResultSet rs=ste.executeQuery("SELECT  category.IdCategory, category.NameCategory, category.DescriptionCategory, \n" +
"            sum(product.QuantityProduct) as total FROM category \n" +
"            INNER JOIN product ON product.NameCategory=category.NameCategory \n" +
"            GROUP by category.NameCategory ORDER By total DESC");
     while (rs.next()) {  

         int IdCategory=rs.getInt(1);  
         String NameCategory=rs.getString("category.NameCategory");
               String DescriptionCategory=rs.getString("category.DescriptionCategory");
               int total=rs.getInt("total");
             
       Category c1=new Category(IdCategory, NameCategory, DescriptionCategory,total);
     arr.add(c1);
     }
    return arr;
    }

    
    public void ajouter(Category t) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
  
    
    public List<Category> recherche(String aa) throws SQLException{
         List<Category> fish=new ArrayList<>();
         ste=con.createStatement();
        ResultSet rs=ste.executeQuery("Select * from category where NameCategory like '%" + aa + "%' ;");
           while (rs.next()) {                
            
               String NameCategory=rs.getString("NameCategory");
               String DescriptionCategory=rs.getString("DescriptionCategory");
             
               
               
               Category c=new Category(NameCategory, DescriptionCategory);
     fish.add(c);
     }
        return fish;
    }
    
    public List<Category> trieln() throws SQLException{
         List<Category> fish=new ArrayList<>();
         ste=con.createStatement();
        ResultSet rs=ste.executeQuery("Select * from category order by length(NameCategory) desc;");
           while (rs.next()) {                
            
               String NameCategory=rs.getString("NameCategory");
               String DescriptionCategory=rs.getString("DescriptionCategory");
               
              
               
               
               Category x=new Category(NameCategory, DescriptionCategory);
     fish.add(x);
     }
        return fish;
    }

    public void like() {
    } 

    @Override
    public void add(Category t) throws SQLException {
         PreparedStatement pre=con.prepareStatement("INSERT INTO `hooks`.`category` (`IdCategory`, `NameCategory`, `DescriptionCategory`) VALUES ( NULL, ?, ?);");
    
    pre.setString(1, t.getNameCategory());
    pre.setString(2, t.getDescriptionCategory());
    pre.executeUpdate();
    }

    @Override
    public void delete(Category t) throws SQLException {
       PreparedStatement pre=con.prepareStatement("delete from category WHERE IdCategory='"+t.getIdCategory()+"';");
            pre.executeUpdate();
            }

    @Override
    public void update(Category t) throws SQLException {
         PreparedStatement pre=con.prepareStatement("UPDATE category SET NameCategory= ?,  DescriptionCategory= ?  WHERE IdCategory='"+t.getIdCategory()+"';");
        pre.setString(1, t.getNameCategory());
    pre.setString(2, t.getDescriptionCategory());    
        pre.executeUpdate();
       
      }

    @Override
    public List<Category> readAll(Category t) throws SQLException {
      List<Category> arr=new ArrayList<>();
    ste=con.createStatement();
        
    ResultSet rs=ste.executeQuery("Select * from category");
     while (rs.next()) {  

         int IdCategory=rs.getInt(1);  
         String NameCategory=rs.getString(2);
               String DescriptionCategory=rs.getString(3);
               //int total=rs.getInt(4);  
       Category c1=new Category(IdCategory, NameCategory, DescriptionCategory);
     arr.add(c1);
     }
     
    return arr;
    }

  
}
