/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hooksandhorns;
import Service.ServiceClient;
import Service.Servicewishlist;
import entite.Client;
import entite.wishlist;
import static java.sql.JDBCType.NULL;
import java.sql.SQLException;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author asus
 */
public class Hooksandhorns {
       
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ServiceClient ser=new ServiceClient();
        Servicewishlist ser2=new Servicewishlist();
        Client c=new Client("jasser.kh@yahoo","pp","ppp","opooo","tt");
        wishlist w=new wishlist(99,"hh");
        
        
            /*  try {
            ser.ajouter(c);
            } catch (SQLException ex) {
            System.out.println(ex);
            }*/
            /*try{ ser.delete(c);
            } catch (SQLException ex) {
            System.out.println(ex);
            }*/
        try {
            ser.update(c);
             } catch (SQLException ex) {
            System.out.println(ex);
        }
            /* try {
            ser2.ajouter(w);
            } catch (SQLException ex) {
            System.out.println(ex);
            }*/
            /*List<Client> list = null;
            try {
            list = ser.readAll();
            
            } catch (SQLException ex) {
            System.out.println(ex);
            }
            System.out.println(list);*/
       
    }
    
    }
    

  //    ser.ajouter(d2);
              //ser.delete(c);
          //ser.update(c);
         //  List<Client> list = ser.readAll();