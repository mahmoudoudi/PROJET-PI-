/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import IService.IService;
import Utils.Database;
import entities.Client;
import entities.FidelityCard;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author asus
 */
public class ServiceFidelityCard implements IService <FidelityCard> {
     private final Connection con;
    private Statement ste;

    public ServiceFidelityCard() {
        con = Database.getInstance().getConnection();

    }
    
  

    @Override
    public void add(FidelityCard t) throws SQLException {
          ste = con.createStatement();

        String requeteInsert = "INSERT INTO fidelitycard ( IdFidelityCard, Points,IdClient)"
               
                + "VALUES "
                + "(NULL, '" + t.getPoints()+ "', '" + t.getIdClient() + "');";
        ste.executeUpdate(requeteInsert);
    }

    @Override
    public void delete(FidelityCard t) throws SQLException {
      ste = con.createStatement();
        String sql = "delete from FidelityCard where IdFidelityCard='"+t.getIdFidelityCard()+ "' ";
        ste.executeUpdate(sql);
    }

    @Override
    public void update(FidelityCard t) throws SQLException {
       
    }

    @Override
    public List<FidelityCard> readAll(FidelityCard t) throws SQLException {
       List<FidelityCard> arr = new ArrayList<>();
        ste = con.createStatement();
        ResultSet rs = ste.executeQuery("select * from FidelityCard");
        while (rs.next()) {

            int id= rs.getInt(1);
            int name = rs.getInt(2);
           int lastname = rs.getInt(3);
           

            FidelityCard p = new FidelityCard(id, name, lastname);
            arr.add(p);
        }
        return arr;
    
    }
 public List<FidelityCard> readAllf() throws SQLException {
       List<FidelityCard> arr = new ArrayList<>();
        ste = con.createStatement();
        ResultSet rs = ste.executeQuery("select * from fidelitycard");
        while (rs.next()) {

            int id= rs.getInt(1);
            int name = rs.getInt(2);
           int lastname = rs.getInt(3);
           

            FidelityCard p = new FidelityCard(id, name, lastname);
            arr.add(p);
        }
        return arr;
    
    }
}
