/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import Service.ServiceClient;
import Service.ServiceFidelityCard;
import Utils.Database;
import entities.FidelityCard;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;

/**
 * FXML Controller class
 *
 * @author asus
 */
public class FrontController implements Initializable {
    @FXML
    private Hyperlink accountclient;
    @FXML
    private GridPane shop;
    @FXML
    private GridPane events;
    @FXML
    private GridPane news;
    @FXML
    private GridPane contact;
    @FXML
    private GridPane account;
    @FXML
    private TextField name;
    @FXML
    private TextField lastname;
    @FXML
    private TextField oldpassword;
    @FXML
    private TextField newpassword;
    @FXML
    private TextField address;
    @FXML
    private Button add;
    @FXML
    private Label labelupdateinfo;
     @FXML
    private Label idclient;
     @FXML
    private Label nameclient;
     @FXML
    private Label labelwish;
    @FXML
    private GridPane gridwishlist;
    @FXML
    private Button s;
    @FXML
    private Button e;
    @FXML
    private Button n;
    @FXML
    private Button c;
    @FXML
    private Hyperlink fid;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
     /*  String o= idclient.getText();
    int i = Integer.parseInt(o);
        getidclient(i);
        System.out.println(o);
        try {
            sessionw (i);
        } catch (SQLException ex) {
            Logger.getLogger(FrontController.class.getName()).log(Level.SEVERE, null, ex);
        }*/
    }    

    @FXML
    private void goaccount(ActionEvent event) {
    }


    @FXML
    private void addclient(ActionEvent event) {
    }

    @FXML
    private void back(MouseEvent event) {
    }

    @FXML
    private void grids(ActionEvent event) {
    }
     public void getidclient(int c) {
       
     String s=String.valueOf(c);
     
      this.idclient.setText(s);
     }
      public void getname(String c) {
       
      this.nameclient.setText(c);
     // nameclient.setText("hdf");
    }
      public void sessionw (int i) throws SQLException{
        ServiceClient e=new ServiceClient ();
       
       boolean a= e.session(i);
       if (a==true){
             labelwish.setText("Your Points: ");
             fid.setText("");
       }
       else if (a==false ){
           fid.setText("want fidelity card?");
       }
      }
   @FXML
    public void addf( ){
      int c=0;
     String o= idclient.getText();
    int i = Integer.parseInt(o);
        ServiceFidelityCard u=new ServiceFidelityCard();
        int points=0;
       
       FidelityCard f=new FidelityCard(points,i);
       
      
                try {
                   u.add(f);
                   
                    String status = "success";
                    fid.setText("thank you");

                } catch (SQLException ex) {
                    System.out.println(ex);
                }
    
        System.out.println("ha");
    
    }

   
}
