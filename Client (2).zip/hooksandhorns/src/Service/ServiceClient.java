/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;
import Utils.DataBase;
import IService.IService;
import java.sql.SQLException;
import java.util.List;
import entite.Client;
import entite.wishlist;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;



/**
 *
 * @author asus
 */
public class ServiceClient implements IService <Client> {
  private Connection con;
    private Statement ste;

    public  ServiceClient() {
        con = DataBase.getInstance().getConnection();

    }

    /**
     *
     *
    pre.executeUpdate();
     * @param t
     * @throws SQLException
     */
    @Override
    
    public void ajouter(Client t) throws SQLException {
 ste = con.createStatement();
            
        String requeteInsert = "INSERT INTO client ( IdClient, EmailClient, Name,"
                + "LastName, Password ,Adress) "
                + "VALUES "
                + "(NULL, '" + t.getEmailClient() + "', '" + t.getName() + "', '" + t.getLastName() + " ', '" + t.getPassword() + "'"
                + ", '" + t.getAdress() + " ');";
        ste.executeUpdate(requeteInsert);
    }

    @Override
    public boolean delete(Client c) throws SQLException {
        ste=con.createStatement();
    String sql="delete from client where EmailClient='"+c.getEmailClient()+"' ";
        ste.executeUpdate(sql);
        return true;
    }

    @Override
    public boolean update(Client c) throws SQLException {
      
           ste=con.createStatement();
    String sql="update client Set EmailClient='"+c.getEmailClient()+"', Name='"+c.getName()+"',LastName='"+c.getLastName()+"',"
            + "Password='"+c.getPassword()+"',Adress='"+c.getAdress()+"' where EmailClient='"+c.getEmailClient()+"' ";
        ste.executeUpdate(sql);
        return true;
    } 

    @Override
    public List<Client> readAll() throws SQLException {
           List<Client> arr=new ArrayList<>();
    ste=con.createStatement();
    ResultSet rs=ste.executeQuery("select * from client");
     while (rs.next()) {                
              
               String email=rs.getString(1);
               String name=rs.getString(2);
               String lastname=rs.getString(3);
               String pw=rs.getString(4);
               String rpw=rs.getString(5);
              
               
               Client p=new Client (email, name, lastname,pw,rpw);
     arr.add(p);
     }
    return arr;
    }

  

    
}
