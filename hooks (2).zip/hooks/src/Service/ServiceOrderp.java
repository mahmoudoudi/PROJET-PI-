/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import IService.IService;
import Utils.Database;
import entities.FidelityCard;
import entities.Orderp;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author asus
 */
public class ServiceOrderp implements IService <Orderp> {

    private Connection con;
    private Statement ste;

    public ServiceOrderp() {
        con = Database.getInstance().getConnection();

    }
    @Override
    public void add(Orderp t) throws SQLException {
        try {
        int idp;
        float prix;
        // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        ste = con.createStatement();
        ste = con.createStatement();
        PreparedStatement p= con.prepareStatement("delete from cart WHERE IdClient='"+t.getIdClient()+"';");
    
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        ResultSet r=ste.executeQuery("SELECT SUM(Total) FROM cart WHERE IdClient='"+t.getIdClient()+"'");
         ResultSet rs=ste.executeQuery("SELECT SUM(Total) FROM cart WHERE IdClient='"+t.getIdClient()+"'");
        //ResultSet rs=ste.executeQuery("SELECT * FROM `product` WHERE IdProduct='"+t.getIdProduct()+"'");
        while(r.next()){
            //int coun=r.getInt(2);
            prix = r.getFloat("SUM(Total)");
            String requeteInsert="INSERT INTO `orderp` (`IdOrder`,`IdClient`, `EmailClient`, `PhoneNumber`, `PaymentMethod`,`TotalO`) "
           + "VALUES (NULL, '" + t.getIdClient() + "','" + t.getEmailClient() + "', '" + t.getPhoneNumber() + "', '" + t.getPaymentMethod() + "','" + prix + "');";

ste.executeUpdate(requeteInsert); 
            
         //   System.out.println(coun);
            
 
                
            } 
    p.executeUpdate();
    }  catch (SQLException ex) {
            System.out.println(ex);
    }
    }
 public void valider(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   
    public double calculerTotal(int idUser) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void delete(Orderp t) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void update(Orderp t) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Orderp> readAll(Orderp t) throws SQLException {
      //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    List<Orderp> arr=new ArrayList<>();
    ste=con.createStatement();
   // ResultSet r=ste.executeQuery("select * from product");
    ResultSet rs=ste.executeQuery("select * from orderp ");
     while (rs.next()) {                
               //int idc=rs.getInt(1);
              // int idcl=rs.getInt(2);
               int ido =rs.getInt(1);
               int idc=rs.getInt(2);
               String mail=rs.getString(3);
               int phone=rs.getInt(4);
               String methode=rs.getString(5);
               float total=rs.getFloat(6);
               //String nomp=r.getString(3);
               
              
               Orderp o=new Orderp ( ido, idc, mail ,phone,methode, total);
     arr.add(o);
     }
    return arr;
    
    }
    public List<Orderp> readAllo() throws SQLException {
      List<Orderp> arr=new ArrayList<>();
    ste=con.createStatement();
   // ResultSet r=ste.executeQuery("select * from product");
    ResultSet rs=ste.executeQuery("select * from orderp ");
     while (rs.next()) {                
               //int idc=rs.getInt(1);
              // int idcl=rs.getInt(2);
              int ido =rs.getInt(1);
               int idc=rs.getInt(2);
               String mail=rs.getString(3);
               int phone=rs.getInt(4);
               String methode=rs.getString(5);
               float total=rs.getFloat(6);
               //String nomp=r.getString(3);
               
              
               Orderp o=new Orderp (ido,idc, mail ,phone,methode, total);
     arr.add(o);
     }
    return arr;
    }
}
