/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package IService;

import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author asus
 * @param <Client>
 */
public interface IService <Client> {
    
     void ajouter(Client c) throws SQLException;
    boolean delete(Client c) throws SQLException;
    boolean update(Client c) throws SQLException;
    List<Client> readAll() throws SQLException;
}
