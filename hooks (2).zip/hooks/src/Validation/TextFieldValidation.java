/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Validation;

import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

/**
 *
 * @author Dr
 */
public class TextFieldValidation {
    
    public static boolean isTextFieldNotEmpty(TextField tf){
        
        boolean b = false;
        if(tf.getText().length()!=0 || !tf.getText().isEmpty() )
            b=true;
        return b;
    
    }
       public static boolean isTextFieldNotEmpty(TextArea ta){
        
        boolean b = false;
        if(ta.getText().length()!=0 || !ta.getText().isEmpty() )
            b=true;
        return b;
    
    }
    public static boolean isTextFieldNotEmpty(TextField tf,Label lb,String ErreurMessage){
        
        boolean b = true;
        String msg = null;
        if(!isTextFieldNotEmpty(tf)){
            b=false;
        msg = ErreurMessage;
        }
        lb.setText(msg);
        return b;
    
    }
      public static boolean isTextFieldNotEmpty(TextArea ta,Label lb,String ErreurMessage){
        
        boolean b = true;
        String msg = null;
        if(!isTextFieldNotEmpty(ta)){
            b=false;
        msg = ErreurMessage;
        }
        lb.setText(msg);
        return b;
    
    }
      public static boolean isDateFormatValid(TextField tf)
      {
          boolean b = false;
          if(tf.getText().matches("^\\d{4}[-]?\\d{1,2}[-]?\\d{1,2} \\d{1,2}:\\d{1,2}:\\d{1,2}[.]?\\d{1,6}$"))
              b=true;
          return b ;
      }
            public static boolean isDateFormatValid(TextField tf,Label lb,String ErreurMessage){
        
        boolean b = true;
        String msg = null;
        if(!isDateFormatValid(tf)){
            b=false;
        msg = ErreurMessage;
        }
        lb.setText(msg);
        return b;
    
    }
    
}
