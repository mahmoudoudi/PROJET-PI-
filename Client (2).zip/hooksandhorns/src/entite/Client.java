/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entite;
import java.sql.JDBCType;
import java.util.*;

/**
 *
 * @author asus
 */
public class Client {
     private int IdClient;
    private String  EmailClient;
    private String Name ;
    private String LastName;
    private String Password;
    private String Adress;

    public Client(int IdClient, String EmailClient, String Name, String LastName, String Password, String Adress) {
        this.IdClient = IdClient;
        this.EmailClient = EmailClient;
        this.Name = Name;
        this.LastName = LastName;
        this.Password = Password;
        this.Adress = Adress;
    }

    public Client(String EmailClient, String Name, String LastName, String Password, String Adress) {
        this.EmailClient = EmailClient;
        this.Name = Name;
        this.LastName = LastName;
        this.Password = Password;
        this.Adress = Adress;
    }

    

    public int getIdClient() {
        return IdClient;
    }

    public String getEmailClient() {
        return EmailClient;
    }

    public String getName() {
        return Name;
    }

    public String getLastName() {
        return LastName;
    }

    public String getPassword() {
        return Password;
    }

    public String getAdress() {
        return Adress;
    }

    public void setIdClient(int idClient) {
        this.IdClient = idClient;
    }

    public void setEmailClient(String EmailClient) {
        this.EmailClient = EmailClient;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public void setLastName(String LastName) {
        this.LastName = LastName;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    public void setAdress(String Adress) {
        this.Adress = Adress;
    }

    
    @Override
    public String toString() {
        return "Client{" + "idClient=" + IdClient + ", EmailClient=" + EmailClient + ", Name=" + Name + ", LastName=" + LastName + ", Password=" + Password + ", adress=" + Adress + '}';
    }

    
}