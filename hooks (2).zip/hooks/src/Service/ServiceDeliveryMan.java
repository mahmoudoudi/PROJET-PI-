/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import IService.IService;
import Utils.Database;
import entities.DeliveryMan;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 *
 * @author asus
 */
public class ServiceDeliveryMan implements IService <DeliveryMan>{
     private Connection con;
    private Statement ste;

    public ServiceDeliveryMan() {
        con = Database.getInstance().getConnection();

    }

    
public boolean updateN(DeliveryMan t, int i) throws SQLException {
      

        boolean test=false;
            PreparedStatement pre= con.prepareStatement(  "UPDATE deliveryman SET NameD= ?,  LastNameD= ?, AddressD= ?, EmailDeliveryman= ?, PhoneNumberD= ? WHERE IdDeliveryman='"+i+"';");
            pre.setString(1, t.getFirstname());
    pre.setString(2, t.getLastname());
    pre.setString(3, t.getAddress());
    pre.setString(4, t.getEmail());
    pre.setInt(5, t.getPhonenumber());
//    pre.setString(6, t.getPasswordD());
    pre.executeUpdate();
            return true;
    }

public boolean updateM(DeliveryMan t, int i) throws SQLException {
      

        boolean test=false;
            PreparedStatement pre= con.prepareStatement(  "UPDATE deliveryman SET NameD= ?,  LastNameD= ?, AddressD= ?, EmailDeliveryman= ?, PhoneNumberD= ? ,PasswordD=? WHERE IdDeliveryman='"+i+"';");
            pre.setString(1, t.getFirstname());
    pre.setString(2, t.getLastname());
    pre.setString(3, t.getAddress());
    pre.setString(4, t.getEmail());
    pre.setInt(5, t.getPhonenumber());
    pre.setString(6,t.getPasswordD());
    pre.executeUpdate();
            return true;
    }
public boolean updateP(DeliveryMan t, int i, String x) throws SQLException {
      

        boolean test=false;
            PreparedStatement pre= con.prepareStatement(  "UPDATE deliveryman SET NameD= ?,  LastNameD= ?, AddressD= ?, EmailDeliveryman= ?, PhoneNumberD= ? ,PasswordD=? WHERE IdDeliveryman='"+i+"';");
            pre.setString(1, t.getFirstname());
    pre.setString(2, t.getLastname());
    pre.setString(3, t.getAddress());
    pre.setString(4, t.getEmail());
    pre.setInt(5, t.getPhonenumber());
    pre.setString(6, x);
    pre.executeUpdate();
            return true;
    }
  public String etat () throws SQLException {
     ste = con.createStatement();
ResultSet rs=ste.executeQuery("SELECT Available FROM deliveryman where IdDeliveryman=2");
while (rs.next())
        {
         String y=rs.getString("Available");
         return y;
        }
return "a";
    }
  
     
  

   

//    @Override
//    public boolean update(DeliveryMan t) throws SQLException {
//            boolean test=false;
//
//            PreparedStatement ste= con.prepareStatement(  " UPDATE `hooks`.`deliveryman` SET `NameD`= ?,`LastNameD`= ?,  `AddressD`= ?,`EmailDeliveryman`= ?,`PhoneNumberD`= ?,`Available`= ? WHERE `IdDeliveryman`=?");
//            ste.setString(1,t.getFirstname() );
//              ste.setString(2,t.getLastname() );
//                ste.setString(3,  t.getAddress() );
//                  ste.setString(4, t.getEmail() );
//                  ste.setInt(5,t.getPhonenumber()  );
//                    ste.setString(6,t.getAvailable()  );
//                    ste.setInt(7,t.getId() );
//                    System.out.println(ste);
//                        ste.executeUpdate();
//            return true;
//    }
//    

 
    public List<DeliveryMan> readAll2() throws SQLException {
           List<DeliveryMan> arr=new ArrayList<>();
    ste=con.createStatement();
    ResultSet rs=ste.executeQuery("select * from deliveryman ");
     while (rs.next()) {                
               int id=rs.getInt("IdDeliveryman");
               String NameD=rs.getString("NameD");
               String LastNameD=rs.getString("LastNameD");
               String AddressD=rs.getString("AddressD");
               String EmailDeliveryman=rs.getString("EmailDeliveryman");
               int PhoneNumberD=rs.getInt("PhoneNumberD");
               String Available=rs.getString("Available");
               float Score=rs.getFloat("Score");
               float NumberScore=rs.getFloat("NumberScore");

               DeliveryMan p=new DeliveryMan (id, NameD, LastNameD, AddressD, EmailDeliveryman, PhoneNumberD, Available, Score, NumberScore);
     arr.add(p);
     }
    return arr;
    }

  
    public boolean searchbyname(String NameD) throws SQLException {
        boolean test=false;
    String sql = "SELECT * FROM `hooks`.`deliveryman` WHERE NameD=?";
 
PreparedStatement statement = con.prepareStatement(sql);
statement.setString(1, NameD);
ResultSet rst=ste.executeQuery(sql);
rst.last();
int nbrows=rst.getRow();
    if(nbrows!=0){
        System.out.println("deliveryman found");
        test=true;
        
    }
    else{
        System.out.println("deliveryman not found");
    }
 
return false;
    }

  
   
    public List<DeliveryMan> searchDeliveryByID(String AddressDdelivery) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

   
    public List<DeliveryMan> searchDeliverymanByName(String NameD) throws SQLException {
      String requete="SELECT * FROM `hooks`.`deliveryman`where NameD= '"+NameD+"'" ;
        ste=con.createStatement() ;
        ResultSet rs=ste.executeQuery(requete);
        List<DeliveryMan> list = new ArrayList<>() ; 
        while(rs.next()){
        DeliveryMan d;
            d = new DeliveryMan(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getInt(6),
            rs.getString(7));
        list.add(d) ;
        }
        return list ;
    }

   
    public List<DeliveryMan> searchbyid(int id) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
        public void statistiquesOffre(Map<String,Double> maps) throws SQLException
        {
            
             String requete1="SELECT distinct(destination) from delivery";
             ste=con.createStatement() ;
             ResultSet rs=ste.executeQuery(requete1);
             List<String> types = new ArrayList<>();
             while(rs.next())
             {
                types.add(rs.getString(1));
             }

            
             int total=0;
             String requete2="Select count(ID_OFFRE) from offre  " ;
             ste=con.createStatement() ;
             rs=ste.executeQuery(requete2);
             while(rs.next())
             {
             total=rs.getInt(1);
             }

            
             int i=0;

             for(i=0;i<types.size();i++)
             {
                 String requete="Select count(ID_OFFRE) from offre o join espace e on e.ID_ESPACE=o.ID_ESPACE WHERE e.TYPE_ES='"+types.get(i)+"' " ;
                    ste=con.createStatement() ;
                    rs=ste.executeQuery(requete);
                    Double nbro=0.0;
                    String nomesp="";
                    Double moyesp=0.0;                    
                    while(rs.next())
                    {
                    nomesp=types.get(i);
                    nbro=rs.getDouble(1);
                    moyesp=(nbro / total)*100;
                    Double  b = Math.PI;
                    maps.put(nomesp,moyesp);
                    }

             }
    

   
        }
          public String sendSms(String msg,long num) {
		try {
			// Construct data
			String apiKey = "apikey=" + "5Kpn3qayaKI-S7ESsrfAyPesZlMovvIRk2XC04WGxa";
			String message = "&message=" + msg;
			String sender = "&sender=" + "HealthCare";
                        String numbers = "&numbers=" + "21623524123";
		//	String numbers = "&numbers=" + "00216"+String.valueOf(num);
			
			// Send data
			HttpURLConnection conn = (HttpURLConnection) new URL("https://api.txtlocal.com/send/?").openConnection();
			String data = apiKey + numbers + message + sender;
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Length", Integer.toString(data.length()));
			conn.getOutputStream().write(data.getBytes("UTF-8"));
			final BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			final StringBuffer stringBuffer = new StringBuffer();
			String line;
			while ((line = rd.readLine()) != null) {
				stringBuffer.append(line);
			}
			rd.close();
			
			return stringBuffer.toString();
		} catch (Exception e) {
			System.out.println("Error SMS "+e);
			return "Error "+e;
		}
	}
           

    @Override
    public void add(DeliveryMan t) throws SQLException {
        ste = con.createStatement();
        
        String requeteInsert = "INSERT INTO `hooks`.`deliveryman` (`IdDeliveryman`, `NameD`, `LastNameD`, `AddressD` , "
                + "`EmailDeliveryman` , `PasswordD` , `PhoneNumberD` , `Available`, `Score`, `NumberScore` )"
                + " VALUES (NULL, '" + t.getFirstname() + "', '" + t.getLastname() + "', '" + t.getAddress() + "', '" + t.getEmail() + "', '" + t.getPhonenumber() + "', '" 
                + t.getPhonenumber() + "', '" + t.getAvailableI() + "','" + 0 + "','" + 0 + "');";
        ste.executeUpdate(requeteInsert);
    }
public boolean delete1(int i) throws SQLException {
          PreparedStatement pre=con.prepareStatement("delete from deliveryman WHERE IdDeliveryman='"+i+"';");
            pre.executeUpdate();
         return true;   
    }

    @Override
    public void delete(DeliveryMan t) throws SQLException {
        boolean test=false;
    String sql = "DELETE FROM `hooks`.`deliveryman` WHERE IdDeliveryman=?";
 
PreparedStatement statement = con.prepareStatement(sql);
statement.setInt(1, t.getId());
 
int rowsDeleted = statement.executeUpdate();
if (rowsDeleted > 0) {
    System.out.println("A deliveryman was deleted successfully!");
    test=true;
}

    }

    @Override
    public void update(DeliveryMan t) throws SQLException {
          

            PreparedStatement ste= con.prepareStatement(  " UPDATE `hooks`.`deliveryman` SET `NameD`= ?,`LastNameD`= ?,  `AddressD`= ?,`EmailDeliveryman`= ?,`PhoneNumberD`= ?,`Available`= ? WHERE `IdDeliveryman`=?");
            ste.setString(1,t.getFirstname() );
              ste.setString(2,t.getLastname() );
                ste.setString(3,  t.getAddress() );
                  ste.setString(4, t.getEmail() );
                  ste.setInt(5,t.getPhonenumber()  );
                    ste.setString(6,t.getAvailable()  );
                    ste.setInt(7,t.getId() );
                    System.out.println(ste);
                        ste.executeUpdate();
             
            
            
//    boolean test=false;
//      PreparedStatement pre =con.prepareStatement("UPDATE deliveryman SET PasswordD=? WHERE PhoneNumberD=?");
//      pre.setString(1, t.getPasswordD());
//      pre.setInt(2, t.getPhonenumber());
//      pre.executeUpdate();
      
  
    }

    @Override
    public List<DeliveryMan> readAll(DeliveryMan t) throws SQLException {
         List<DeliveryMan> arr=new ArrayList<>();
    ste=con.createStatement();
    ResultSet rs=ste.executeQuery("select * from deliveryman ");
     while (rs.next()) {                
               int id=rs.getInt("IdDeliveryman");
               String NameD=rs.getString("NameD");
               String LastNameD=rs.getString("LastNameD");
               String AddressD=rs.getString("AddressD");
               String EmailDeliveryman=rs.getString("EmailDeliveryman");
                String PasswordD=rs.getString("PasswordD");
               int PhoneNumberD=rs.getInt("PhoneNumberD");
               String Available=rs.getString("Available");
               
               float Score=rs.getFloat("Score");
               float NumberScore=rs.getFloat("NumberScore");

               DeliveryMan p=new DeliveryMan (id, NameD, LastNameD, AddressD, EmailDeliveryman, PhoneNumberD, Available, Score, NumberScore,PasswordD);
     arr.add(p);
     }
    return arr;
          
    }
        
    
}
